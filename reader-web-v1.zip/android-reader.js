/* ══════════ CONTENT: real where sourced (window.WSC), placeholder elsewhere ══════════ */
/* Translation packs opt in with component.translationOf="bco" and component.language. */
function bcoTranslations(){
  return (window.BUNDLED_PACKS||[]).filter(p=>p.kind==='book'&&p.component&&p.component.translationOf==='bco'&&p.component.language);
}
function readBcoLanguage(){
  try{ return localStorage.getItem('pcacon.bcoLanguage')||'auto'; }catch(_){ return 'auto'; }
}
function chooseBcoEdition(preference=readBcoLanguage()){
  const packs=bcoTranslations();
  const languages=new Set(packs.map(p=>String(p.component.language).toLowerCase().split(/[-_]/)[0]));
  const preferred=(preference==='auto' ? (navigator.languages?.length?navigator.languages:[navigator.language||'en']) : [preference]).map(tag=>String(tag).toLowerCase().split(/[-_]/)[0]);
  const lang=preferred.find(x=>x==='en'||languages.has(x));
  const pack=lang&&packs.find(p=>String(p.component.language).toLowerCase().split(/[-_]/)[0]===lang);
  if(!pack) return {lang:'en',map:window.BCO,label:'English',component:{},notice:''};
  const map=Object.assign({},window.BCO);
  for(const id of pack.order||Object.keys(pack.chapters||{})){
    const chapter=(pack.chapters||{})[id];
    if(chapter&&map[id]){
      const base=map[id];
      const sourceSections=new Map((base.sections||[]).map(s=>[s.ref,s]));
      map[id]=Object.assign({},base,chapter,{part:base.part,paras:chapter.paras||[],
        sections:(chapter.sections||[]).map(s=>{
          const source=sourceSections.get(s.ref);
          return Object.assign(source&&source.binding!==undefined?{binding:source.binding}:{},s);
        })});
    }
  }
  return {lang,map,label:pack.component.name||pack.label||lang,component:pack.component,notice:pack.notice||''};
}
let BCO_EDITION=chooseBcoEdition();
let BCO_DATA=BCO_EDITION.map;
const BCO_APPENDIX_H_FIGURES = {
  en:{src:'diagrams/appendix-h.svg',alt:'Appendix H flowchart: Presbytery appellate court procedures'},
  es:{src:'diagrams/appendix-h.es.svg',alt:'Diagrama del Apéndice H: procedimientos de los tribunales de apelación del presbiterio'},
  ko:{src:'diagrams/appendix-h.ko.svg',alt:'부록 H: 노회 상소 치리회 절차 흐름도'},
};
const LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.";
const SHORT_LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.";
// curated opening questions (the rest are generated placeholders in the long scroll)
const CAT_CURATED = {
  "Q.1":{q:"What is the chief end of man?", body:`Man's chief end is to glorify God,<sup class="pf" data-pf="a">a</sup> and to enjoy him for ever.<sup class="pf" data-pf="b">b</sup>`, proofs:`<b>a</b> 1 Cor. 10:31; Rom. 11:36.&nbsp;&nbsp; <b>b</b> Ps. 73:25–28.`,
    verses:`<div class="v"><span class="vref">1 Cor. 10:31</span> — Whether therefore ye eat, or drink, or whatsoever ye do, do all to the glory of God.</div><div class="v"><span class="vref">Ps. 73:25–26</span> — Whom have I in heaven but thee? … God is the strength of my heart, and my portion for ever.</div>`},
  "Q.2":{q:"What rule hath God given to direct us how we may glorify and enjoy him?", body:`The Word of God, which is contained in the Scriptures of the Old and New Testaments, is the only rule to direct us how we may glorify and enjoy him.<sup class="pf" data-pf="a">a</sup>`, proofs:`<b>a</b> 2 Tim. 3:16; Eph. 2:20.`,
    verses:`<div class="v"><span class="vref">2 Tim. 3:16</span> — All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction…</div>`},
  "Q.3":{q:"What do the Scriptures principally teach?", body:`The Scriptures principally teach what man is to believe concerning God, and what duty God requires of man.`},
};

const COMPONENTS = {
  wcf:{abbr:"WCF", mode:"paged", name:"Westminster Confession of Faith", division:"doctrinal",
    tag:"The church's confession of what the Scriptures teach.",
    lede:"The Confession sets out, in thirty-three chapters, the system of doctrine the Scriptures teach — in the PCA's received (American) revision, each clause supported by Scripture proof-texts.",
    meta:"33 chapters · American revision (1788) · Scripture proof-texts"},
  wlc:{abbr:"WLC", mode:"scroll", name:"Westminster Larger Catechism", division:"doctrinal",
    tag:"The fuller catechism — for exposition and teaching.",
    lede:"One hundred ninety-six questions and answers, expounding the faith more fully than the Shorter Catechism — long used for preaching and instruction.",
    meta:"196 questions & answers · Scripture proof-texts"},
  wsc:{abbr:"WSC", mode:"scroll", name:"Westminster Shorter Catechism", division:"doctrinal",
    tag:"The concise catechism — for learning by heart.",
    lede:"One hundred seven questions and answers, composed to be committed to memory — the most widely learned summary of the faith in the Presbyterian tradition.",
    meta:"107 questions & answers · Scripture proof-texts"},
  bco:bcoComponent(),
};
function bcoComponent(){
  return {abbr:BCO_EDITION.component.abbr||"BCO", mode:"paged", name:BCO_EDITION.lang==='en'?"Book of Church Order":(BCO_EDITION.component.name||BCO_EDITION.label), division:"order",
    tag:BCO_EDITION.component.tag||"How the church is governed, disciplined, and led in worship.",
    lede:BCO_EDITION.component.lede||"The Constitution's governmental standard, in three parts: the Form of Government, the Rules of Discipline, and the Directory for the Worship of God.",
    meta:BCO_EDITION.component.meta||"3 parts · Form of Government · Rules of Discipline · Directory for Worship"};
}

/* WCF chapter titles (standard 33) */
const WCF_CH = [
  "Of the Holy Scripture","Of God, and of the Holy Trinity","Of God's Eternal Decree","Of Creation",
  "Of Providence","Of the Fall of Man, of Sin, and of the Punishment thereof","Of God's Covenant with Man",
  "Of Christ the Mediator","Of Free Will","Of Effectual Calling","Of Justification","Of Adoption",
  "Of Sanctification","Of Saving Faith","Of Repentance unto Life","Of Good Works",
  "Of the Perseverance of the Saints","Of the Assurance of Grace and Salvation","Of the Law of God",
  "Of Christian Liberty, and Liberty of Conscience","Of Religious Worship, and the Sabbath Day",
  "Of Lawful Oaths and Vows","Of the Civil Magistrate","Of Marriage and Divorce","Of the Church",
  "Of the Communion of Saints","Of the Sacraments","Of Baptism","Of the Lord's Supper","Of Church Censures",
  "Of Synods and Councils","Of the State of Men after Death, and of the Resurrection of the Dead",
  "Of the Last Judgment"
];
/* catechisms divide into three classic movements */
const WSC_SECTIONS = [["1","3","Man's chief end, and the rule God has given"],["4","38","What man is to believe concerning God"],["39","107","The duty God requires of man"]];
const WLC_SECTIONS = [["1","5","Man's chief end, and the rule God has given"],["6","90","What man is to believe concerning God"],["91","196","The duty God requires of man"]];
/* BCO parts (chapter lists illustrative in this prototype) */
const BCO_PARTS = [
  {key:"fog", name:"Form of Government", range:"Chapters 1–26",
    chapters:[[1,"Preliminary Principles"],[7,"Church Officers"],[13,"The Presbytery"],[24,"Election of Elders & Deacons","24"],[25,"Organizing a Church"]]},
  {key:"rod", name:"Rules of Discipline", range:"Chapters 27–46",
    chapters:[[27,"The Nature of Discipline"],[31,"Process: Its Nature and Parties","31"],[34,"Cases Without Process"],[42,"References & Appeals"]]},
  {key:"dow", name:"Directory for the Worship of God", range:"Chapters 47–63",
    note:"Mixed authority: most chapters are an approved guide (not binding); some are constitutional. The Preface draws the line.",
    chapters:[[47,"The Principles of Worship"],[51,"The Sanctification of the Lord's Day","51"],[56,"The Administration of Baptism"],[58,"The Lord's Supper"]]},
];

/* the reading SPINE — the ordered sequence prev/next/swipe walks within each component.
   WCF = 33 chapters; catechisms = thematic question-groups; BCO = its chapters flowed across all 3 parts. */
const SPINE = {
  wcf: WCF_CH.map((t,i)=>({ch:String(i+1), title:t})),
  wsc: WSC_SECTIONS.map(([a,b,t])=>({qStart:a, qEnd:b, title:t})),
  wlc: WLC_SECTIONS.map(([a,b,t])=>({qStart:a, qEnd:b, title:t})),
  bco: (window.BCO_ORDER
    ? window.BCO_ORDER.map(id=>({part:BCO_DATA[id].part, ch:id, title:BCO_DATA[id].title, vacated:BCO_DATA[id].vacated}))
    : BCO_PARTS.flatMap(p=>p.chapters.map(ch=>({part:p.key, ch:String(ch[0]), title:ch[1], partName:p.name})))),
};

/* ── custom "book" packs: add whole governing documents (presbytery rules, session
   standing rules, church bylaws). Built-ins and pack-added books flow through one registry,
   so nav / TOC / reader / search / drawer treat them uniformly. ── */
window.BOOK_PACKS = window.BOOK_PACKS || [];
function pagedData(book){               // unified accessor for paged corpora (BCO + custom books)
  if(book==='bco') return window.BCO_ORDER ? {map:BCO_DATA, order:window.BCO_ORDER} : null;
  const bp = window.BOOK_PACKS.find(b=>b.component.key===book);
  return bp ? {map:bp.chapters, order:bp.order} : null;
}
function registerBook(pack){            // make COMPONENTS/SPINE aware of a custom book
  const k = pack.component.key;
  COMPONENTS[k] = Object.assign({mode:'paged', custom:true}, pack.component);
  SPINE[k] = (pack.order||[]).map(id=>({ch:id, title:(pack.chapters[id]||{}).title||''}));
  const i = window.BOOK_PACKS.findIndex(b=>b.component.key===k);
  if(i>=0) window.BOOK_PACKS[i]=pack; else window.BOOK_PACKS.push(pack);
}
const officialSupplements = new Map((window.BUNDLED_PACKS||[])
  .filter(p=>p.kind==='book' && p.component.nonConstitutional && p.component.division==='supplemental'
    && p.notice?.startsWith('Official PCA source: '))
  .map(p=>[p.component.key,p]));
const saveBooks = ()=>{ try{ localStorage.setItem("pcacon.books", JSON.stringify(window.BOOK_PACKS.filter(p=>!officialSupplements.has(p.component.key)))); }catch(e){} };
const DIVISIONS = {                     // home groupings (order = display order)
  doctrinal:{label:"Doctrinal Standards", one:"Doctrinal Standard", order:1},
  order:{label:"Church Order", one:"Church Order", order:2},
  local:{label:"Local Rules & Courts", one:"Local Rule", order:3},
  supplemental:{label:"Supplementary PCA Materials", one:"Supplementary PCA Material", order:4},
};

/* dossiers (drive the margin counts); refs not listed → empty state */
const DOSSIER = {
  "24-1":{quote:"Those who have been called to office in the church…", cases:11, ov:18, inq:5, rpr:30,
    amend:[{ga:"16th (1988)", n:"Renumbering within Ch. 24."},{ga:"39th (2011)", n:"Amended re: term eldership."}]},
  "24-2":{quote:"Ruling elders and deacons, being chosen by the people…", cases:0, ov:1, inq:0, rpr:3, amend:[]},
  "24-4":{quote:"At a congregational meeting called for that purpose…", cases:1, ov:0, inq:0, rpr:2, amend:[]},
  "31-2":{quote:"Process against an offender shall not commence unless…", cases:3, ov:1, inq:1, rpr:0,
    amend:[{ga:"35th (2007)", n:"Clarified the timing of process."}]},
  "31-5":{quote:"It is the duty of all church Sessions and Presbyteries…", cases:1, ov:0, inq:0, rpr:0, amend:[]},
  "51-2":{quote:"The Lord's Day, being the Christian Sabbath…", cases:0, ov:0, inq:1, rpr:0, amend:[]},
  "21.1":{quote:"The light of nature showeth that there is a God…", cases:0, ov:0, inq:0, rpr:1, amend:[]},
  "Q.1":{quote:"Man's chief end is to glorify God, and to enjoy him for ever.", cases:0, ov:0, inq:1, rpr:1, amend:[]},
};

/* user-authored notes (distinct from derived citations) — keyed by the same provision ref */
const NOTES = {
  "Q.1":[{who:"You", when:"Apr 2026", text:"WLC Q.1 gives the fuller treatment of “enjoy him for ever.” Cross-reference for the membership class."}],
  "24-1":[{who:"You", when:"Mar 2026", text:"Note the link to BCO 21 on the manner of ordination."}],
};

/* ── notes + content packs: persistence (localStorage) + portable import/export ── */
window.BCO_COMMENTARIES = window.BCO_COMMENTARIES || [];   // [{label, entries}] — multiple commentary packs (Smith, Ramsay, …)
const PACK_FORMAT = "pca-constitution-pack";
const BCO_EDITION_FORMAT = "pca-reader-bco-edition";
(function restore(){                                   // durable when served; file:// may not persist (export files cover that)
  try{ const n=localStorage.getItem("pcacon.notes"); if(n){ const o=JSON.parse(n); Object.keys(NOTES).forEach(k=>delete NOTES[k]); Object.assign(NOTES, o); } }catch(e){}
  try{
    const cs=localStorage.getItem("pcacon.commentaries");
    if(cs){ window.BCO_COMMENTARIES = (JSON.parse(cs)||[]).filter(c=>c&&c.entries); }
    else { const c=localStorage.getItem("pcacon.commentary");    // migrate the old single-pack key
           if(c){ const o=JSON.parse(c); if(o&&o.entries) window.BCO_COMMENTARIES=[{label:o.label||"Commentary", entries:o.entries}]; } }
  }catch(e){}
  try{
    const bk=localStorage.getItem("pcacon.books");
    if(bk){
      const stored=JSON.parse(bk)||[];
      // These built-in appendix figures were briefly offered as a separate book.
      const books=stored.filter(p=>!(p?.component?.key==='appendix-h-charts' && p.label==='Appendix H Flowcharts'));
      books.forEach(p=>{ if(p&&p.component&&p.component.key) registerBook(p); });
      if(books.length!==stored.length) saveBooks();
    }
  }catch(e){}
})();
officialSupplements.forEach(registerBook);
const saveNotes = ()=>{ try{ localStorage.setItem("pcacon.notes", JSON.stringify(NOTES)); }catch(e){} };
const saveCommentaries = ()=>{ try{
  // Structured commentary blocks already contain the full rendered text. Keep
  // the paragraphs fallback in portable pack files, but omit it from browser
  // storage to avoid storing every commentary entry twice.
  const stored=window.BCO_COMMENTARIES.map(pack=>{
    const compact=value=>{
      if(!value||!Array.isArray(value.blocks)||!Array.isArray(value.paragraphs)) return value;
      const {paragraphs,...structured}=value; return structured;
    };
    const entries=Object.fromEntries(Object.entries(pack.entries||{}).map(([ref,value])=>[ref,compact(value)]));
    const sections=Array.isArray(pack.sections)?pack.sections.map(compact):[];
    return {...pack,entries,sections};
  });
  localStorage.setItem("pcacon.commentaries", JSON.stringify(stored));
  localStorage.removeItem("pcacon.commentary");
}catch(e){ throw e; }
  const chapterCommentary = document.getElementById("chapterCommentary");
  if(view==="read" && chapterCommentary && cur.o) chapterCommentary.innerHTML = chapterCommentaryHtml(cur.o.ch);
};
const noteDate = ()=>{ try{ return new Date().toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"}); }catch(e){ return ""; } };
function packDownload(name, obj){ const u=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)],{type:"application/json"})); const a=document.createElement("a"); a.href=u; a.download=name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(u); }
function exportNotes(){ packDownload("pca-constitution-notes.json", {format:PACK_FORMAT, version:1, kind:"notes", label:"My notes", exported:noteDate(), entries:NOTES}); }
function bcoEditionToBookPack(edition){
  if(edition.version!==1 || !Number.isInteger(edition.edition) || !Array.isArray(edition.order) || !edition.entries || typeof edition.entries!=='object')
    throw new Error("Invalid BCO edition snapshot (expected version 1, edition, order, and entries).");
  if(!edition.order.length || new Set(edition.order).size!==edition.order.length)
    throw new Error("BCO edition snapshot has an empty or duplicated chapter order.");
  const chapters={};
  for(const id of edition.order){
    const entry=edition.entries[id];
    if(!entry || typeof entry!=='object') throw new Error(`BCO edition snapshot is missing ordered entry ${id}.`);
    const sections=[];
    if(entry.paras!=null){
      if(!Array.isArray(entry.paras)) throw new Error(`BCO edition entry ${id} has invalid paragraphs.`);
      if(entry.paras.length) sections.push({prose:true,blocks:entry.paras.map(text=>["p",0,String(text)])});
    }
    if(entry.sections!=null){
      if(!Array.isArray(entry.sections)) throw new Error(`BCO edition entry ${id} has invalid sections.`);
      for(const section of entry.sections){
        if(!section || typeof section.ref!=='string' || !section.ref)
          throw new Error(`BCO edition entry ${id} has a section without a reference.`);
        const converted={ref:section.ref};
        for(const field of ['body','blocks','prose','binding']) if(section[field]!==undefined) converted[field]=section[field];
        sections.push(converted);
      }
    }
    chapters[id]={title:entry.title||id, part:entry.part, sections, vacated:!!entry.vacated};
  }
  const label=edition.label||`PCA Book of Church Order (${edition.edition})`;
  const slug=String(label).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,48).replace(/-$/,'')||'edition';
  return {format:PACK_FORMAT,version:1,kind:'book',label,
    notice:`Historical BCO edition snapshot (${edition.edition}); wording and structure are presented as supplied in the source snapshot.`,
    component:{key:`bco-${edition.edition}-${slug}`,abbr:`BCO ${edition.edition}`,name:label,division:'order',icon:'book',
      tag:`Historical Book of Church Order edition (${edition.edition}).`,
      lede:`Imported from a version 1 BCO edition snapshot for historical reading.`,
      meta:`Historical edition · ${edition.edition}`,historicalBcoEdition:edition.edition},
    order:edition.order.slice(),chapters};
}
function importPack(obj){
  if(obj && obj.format===BCO_EDITION_FORMAT) obj=bcoEditionToBookPack(obj);
  if(!obj || obj.format!==PACK_FORMAT) throw new Error("Not a PCA Constitution pack file.");
  const entries=obj.entries||{}, n=Object.keys(entries).length+(Array.isArray(obj.sections)?obj.sections.length:0);
  if(obj.kind==="notes"){                              // merge (non-destructive), dedup by text
    for(const ref in entries){ const have=NOTES[ref]||(NOTES[ref]=[]); const seen=new Set(have.map(x=>x.text)); (entries[ref]||[]).forEach(x=>{ if(!seen.has(x.text)) have.push(x); }); }
    saveNotes();
  } else if(obj.kind==="commentary"){                  // add, or replace a same-named pack (so re-import updates)
    const label=obj.label||"Commentary", pack={label, entries, sections:Array.isArray(obj.sections)?obj.sections:[], corpus:obj.corpus||"bco"};
    const i=window.BCO_COMMENTARIES.findIndex(c=>c.label===label);
    if(i>=0) window.BCO_COMMENTARIES[i]=pack; else window.BCO_COMMENTARIES.push(pack);
    saveCommentaries();
  } else if(obj.kind==="book"){                        // a whole new corpus (presbytery rules, bylaws…)
    if(!obj.component || !obj.component.key) throw new Error("Book pack missing component.key.");
    if(officialSupplements.has(obj.component.key)) throw new Error("This document is supplied by the reader.");
    registerBook(obj); saveBooks();
    return {kind:obj.kind, n:Object.values(obj.chapters||{}).reduce((a,c)=>a+((c.sections||[]).length),0)};
  } else throw new Error("Unsupported pack kind: "+obj.kind);
  return {kind:obj.kind, n};
}

/* curated chapters with real-feeling text (others are generated lorem) */
const CURATED = {
  "wcf:21":{kicker:"Westminster Confession of Faith", title:"Chapter 21",
    subtitle:"Of Religious Worship, and the Sabbath Day",
    provs:[
      {ref:"21.1", body:`The light of nature showeth that there is a God, who hath lordship and sovereignty over all;<sup class="pf" data-pf="a">a</sup> but the acceptable way of worshipping the true God is instituted by Himself.<sup class="pf" data-pf="b">b</sup>`,
        proofs:`<b>a</b> Rom. 1:20; Ps. 19:1–4.&nbsp;&nbsp; <b>b</b> Deut. 12:32; Matt. 15:9.`,
        verses:`<div class="v"><span class="vref">Rom. 1:20</span> — For the invisible things of him from the creation of the world are clearly seen, being understood by the things that are made…</div><div class="v"><span class="vref">Deut. 12:32</span> — What thing soever I command you, observe to do it: thou shalt not add thereto, nor diminish from it.</div>`},
      {ref:"21.5", body:`The reading of the Scriptures with godly fear; the sound preaching, and conscionable hearing of the Word;<sup class="pf" data-pf="a">a</sup> the singing of psalms with grace in the heart.`,
        proofs:`<b>a</b> Acts 15:21; 2 Tim. 4:2; James 1:22.`},
    ]},
  "bco:fog:24":{kicker:"Book of Church Order · Form of Government", title:"Chapter 24",
    subtitle:"The Election, Ordination, and Installation of Ruling Elders and Deacons",
    railSub:["24-1","24-2","24-3","24-4","24-5"],
    provs:[
      {ref:"24-1", body:`Those who have been called to office in the church are to be inducted by the ordination of a court. ${LOREM}`},
      {ref:"24-2", body:`Ruling elders and deacons, being chosen by the people, ${LOREM}`},
      {ref:"24-3", body:`Before any election shall take place, the Session shall determine the number of officers to be elected. ${LOREM}`},
      {ref:"24-4", body:`At a congregational meeting called for that purpose, ${LOREM}`},
      {ref:"24-5", body:`In every case the man elected must signify his acceptance of the office before being ordained. ${LOREM}`},
    ]},
  "bco:rod:31":{kicker:"Book of Church Order · Rules of Discipline", title:"Chapter 31",
    subtitle:"Of Process, Its Nature and the Parties to It",
    railSub:["31-1","31-2","31-5"],
    provs:[
      {ref:"31-1", body:`Discipline is the exercise of authority given the church by the Lord Jesus Christ. ${LOREM}`},
      {ref:"31-2", body:`Process against an offender shall not commence unless some person undertakes to make out the charge. ${LOREM}`},
      {ref:"31-5", body:`It is the duty of all church Sessions and Presbyteries to exercise care over those subject to their authority. ${LOREM}`},
    ]},
  "bco:dow:51":{kicker:"Book of Church Order · Directory for the Worship of God", title:"Chapter 51",
    subtitle:"The Sanctification of the Lord's Day",
    advisoryNote:`The Directory for the Worship of God is <b>mixed in authority</b>. Most of it is an approved guide — the mind of the Church, but not binding. Certain chapters (e.g. on the sacraments) are <b>constitutional and have the force of law</b>. Each provision is marked; the precise line is drawn by the BCO Preface.`,
    railSub:["51-1","51-2","51-3"],
    provs:[
      {ref:"51-1", con:false, body:`It is the duty of every person to remember the Lord's Day and to prepare for it. ${LOREM}`},
      {ref:"51-2", con:false, body:`The Lord's Day, being the Christian Sabbath, is to be kept holy unto the Lord. ${LOREM}`},
      {ref:"51-3", con:true,  body:`The ordinary public worship of God requires that the people gather. ${LOREM}`},
    ]},
};

function esc(s){ return (s||"").replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
/* ── GA citations: tiny counts manifest is eager (window.CIT_COUNTS); the rows
   are split into content/cit/*.js and loaded on demand (window.CIT[fileid]). ── */
window.CIT = window.CIT || {};
const _citPending = {};
function citCount(comp, ref){ return (window.CIT_COUNTS && window.CIT_COUNTS[comp+'|'+ref]) || 0; }
function citFileId(comp, ref){ return comp==='bco' ? 'bco-'+ref.split('-')[0] : comp; }
function citRows(comp, ref){                         // loaded rows, or null if not yet fetched
  const f = window.CIT[citFileId(comp, ref)];
  return f ? (f[ref] || []) : null;
}
function loadCitFile(comp, ref){                      // inject the split file (works on file:// too)
  const fid = citFileId(comp, ref);
  if(window.CIT[fid]) return Promise.resolve();
  if(_citPending[fid]) return _citPending[fid];
  return _citPending[fid] = new Promise(res => {
    const s = document.createElement('script');
    s.src = 'content/cit/'+fid+'.js';
    s.onload = () => res();
    s.onerror = () => { window.CIT[fid] = {}; res(); };   // missing file ⇒ no citations
    document.head.appendChild(s);
  });
}
const dossierFor = r => {
  const base = DOSSIER[r] || {};
  return {quote: base.quote||"", amend: base.amend||[], count: citCount(current, r)};
};
const total = d => d.count || 0;

// proof texts: references shown by default, full verse text on demand (two-stage)
function proofsBlock(o){
  if(!o.proofs) return '';
  return `<span class="pf-toggle" role="button" tabindex="0">proof texts ▾</span><div class="proofs"><div class="pf-refs">${o.proofs}</div>`
    + (o.verses ? `<button class="pf-more">Show full text ▾</button><div class="pf-verses">${o.verses}</div>` : '')
    + `</div>`;
}
// accessible attributes for a provision's drill-in trigger (the number)
function nAttrs(refLabel, n){
  return `role="button" tabindex="0" aria-label="${refLabel}${n>0?` — ${n} linked GA record${n>1?'s':''}, open citations and notes`:` — open citations and notes`}"`;
}

let view = "home";
let current = "bco";   // current component (for drawer labelling)
let cur = {book:"bco", o:{}};   // current reading location (for prev/next/swipe)

/* Directory for Worship authority note (BCO Preface / 3rd-GA statement) */
const DFW_NOTE = `The Directory for Worship is an approved guide and should be taken seriously as the mind of the Church agreeable to the Standards. However, it does not have the force of law and is not to be considered obligatory in all its parts. <b>BCO 56, 57 and 58</b> and <b>BCO 59-3</b> have been given full constitutional authority; sections with the force of law are marked <b>[ BINDING ]</b>.`;

/* ───────────── chapter builder (real content from window.WCF/BCO, else placeholder) ───────────── */
function buildChapter(book, o){
  // o: {part, ch, title}  OR  {qStart, qEnd, title}  (catechism)
  if(book==="wcf"){
    if(window.WCF && window.WCF[o.ch]){
      const wc = window.WCF[o.ch];
      // demo proofs/verses (until a real proof-text source) — from the curated ch.21 sample, keyed by ref
      const demo = {}; ((CURATED["wcf:21"]||{}).provs||[]).forEach(p=>{ if(p.proofs) demo[p.ref]={proofs:p.proofs, verses:p.verses}; });
      return {kicker:COMPONENTS.wcf.name, title:"Chapter "+o.ch, subtitle:wc.title,
        railSub:wc.sections.map(s=>s.ref),
        provs:wc.sections.map(s=>Object.assign({ref:s.ref, body:s.body}, demo[s.ref]||{}))};
    }
    const key = "wcf:"+o.ch;
    if(CURATED[key]) return CURATED[key];
    return {kicker:COMPONENTS.wcf.name, title:"Chapter "+o.ch, subtitle:o.title,
      railSub:[o.ch+".1",o.ch+".2",o.ch+".3"],
      provs:[1,2,3].map(i=>({ref:o.ch+"."+i, body:LOREM}))};
  }
  if(book==="wsc"||book==="wlc"){
    const c = "wsc:Qsample";
    if(o.qStart==="1"){ // curated opening of the catechism
      return {kicker:COMPONENTS[book].name, title:"Questions "+o.qStart+"–"+o.qEnd, subtitle:o.title, q:true,
        railSub:["Q.1","Q.2","Q.3"],
        provs:[
          {ref:"Q.1", q:"What is the chief end of man?", body:`Man's chief end is to glorify God,<sup class="pf" data-pf="a">a</sup> and to enjoy him for ever.<sup class="pf" data-pf="b">b</sup>`,
            proofs:`<b>a</b> 1 Cor. 10:31; Rom. 11:36.&nbsp;&nbsp; <b>b</b> Ps. 73:25–28.`},
          {ref:"Q.2", q:"What rule hath God given to direct us how we may glorify and enjoy him?", body:`The Word of God, which is contained in the Scriptures of the Old and New Testaments, is the only rule to direct us.<sup class="pf" data-pf="a">a</sup>`,
            proofs:`<b>a</b> 2 Tim. 3:16; Eph. 2:20.`},
          {ref:"Q.3", q:"What do the Scriptures principally teach?", body:`The Scriptures principally teach what man is to believe concerning God, and what duty God requires of man.`},
        ]};
    }
    return {kicker:COMPONENTS[book].name, title:"Questions "+o.qStart+"–"+o.qEnd, subtitle:o.title, q:true,
      railSub:["Q."+o.qStart,"Q."+(+o.qStart+1),"Q."+(+o.qStart+2)],
      provs:[0,1,2].map(i=>({ref:"Q."+(+o.qStart+i), q:"[Question "+(+o.qStart+i)+"]", body:LOREM}))};
  }
  // custom book pack (presbytery rules, bylaws…) — same chapter/section shape as BCO
  if(COMPONENTS[book] && COMPONENTS[book].custom){
    const pd = pagedData(book), bc = pd && pd.map[o.ch];
    const partNames={front:"Preface & Principles",fog:"Form of Government",rod:"Rules of Discipline",dow:"Directory for Worship",appx:"Appendices"};
    const partName=bc&&partNames[bc.part], isNumbered=bc&&['fog','rod','dow'].includes(bc.part);
    const kicker=COMPONENTS[book].name+(partName?" · "+partName:'')+(COMPONENTS[book].nonConstitutional?" · Supplementary PCA material":"");
    const title=bc&&isNumbered?"Chapter "+o.ch:(bc&&(bc.title||("Chapter "+o.ch)));
    const subtitle=bc&&isNumbered?bc.title:"";
    if(bc && bc.vacated) return {kicker, title, subtitle, railSub:[], provs:[{ref:null,body:"This chapter has been vacated."}]};
    if(bc) return {kicker, title, subtitle,
      railSub:(bc.sections||[]).filter(s=>!s.prose).map(s=>s.ref).filter(Boolean),   // skip number-less prose (e.g. an essay appendix)
      provs:(bc.sections||[]).map(s=>({ref:s.ref, body:s.body, blocks:s.blocks, prose:s.prose, con:!!s.binding}))};
  }
  // bco — active edition (English, Spanish, or Korean)
  if(BCO_DATA && BCO_DATA[o.ch]){
    const bc = BCO_DATA[o.ch];
    const PN = BCO_EDITION.component.parts?.[bc.part] || {fog:"Form of Government", rod:"Rules of Discipline", dow:"Directory for the Worship of God"}[bc.part];
    const isChapter = !!PN;
    const kicker = isChapter ? "Book of Church Order · "+PN : (bc.part==='appx' ? "Book of Church Order · Appendices" : "Book of Church Order");
    const title = isChapter ? "Chapter "+o.ch : bc.title;
    const subtitle = isChapter ? bc.title : "";
    if(bc.vacated) return {kicker, title, subtitle, railSub:[], provs:[{ref:null, body:BCO_EDITION.component.vacatedText||"This chapter has been vacated."}]};
    const provs = (bc.paras||[]).map(p=>({ref:null, body:p}))
      .concat((bc.sections||[]).flatMap(s=>{
        const provision={ref:s.ref, body:s.body, blocks:s.blocks, con:bc.part==='dow'&&!!s.binding};
        return s.heading ? [{ref:null,body:`<b>${s.heading}</b>`}, provision] : [provision];
      }));
    if(o.ch==='appH'){
      const figure=BCO_APPENDIX_H_FIGURES[BCO_EDITION.lang]||BCO_APPENDIX_H_FIGURES.en;
      const image=`<img class="pack-figure" src="${figure.src}" alt="${figure.alt}">`;
      if(BCO_EDITION.lang==='en'){
        provs.push({ref:null,body:image});
      } else if(provs[0]?.blocks?.length){
        const [opening,...rest]=provs[0].blocks;
        provs[0]=Object.assign({},provs[0],{blocks:[opening,['p',0,image],...rest]});
      } else {
        provs.splice(Math.min(1,provs.length),0,{ref:null,body:image});
      }
    }
    const advisory = bc.part==='dow' ? DFW_NOTE : '';
    return {kicker, title, subtitle, advisoryNote: advisory||undefined,
      railSub: (bc.sections||[]).map(s=>s.ref), provs};
  }
  const key = "bco:"+o.part+":"+o.ch;
  if(CURATED[key]) return CURATED[key];
  const partName = (BCO_PARTS.find(p=>p.key===o.part)||{}).name;
  return {kicker:"Book of Church Order · "+partName, title:"Chapter "+o.ch, subtitle:o.title,
    railSub:[o.ch+"-1",o.ch+"-2",o.ch+"-3"],
    provs:[1,2,3].map(i=>({ref:o.ch+"-"+i, body:LOREM}))};
}

/* ───────────── views ───────────── */
function setView(v){ view=v; document.body.dataset.view=v; }

const HOME_ICONS = {
  wcf:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="5" y="3" width="14" height="18"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/></svg>`,
  wlc:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 6c-2.2-1.4-4.8-1.6-7.5-1.1v13.2C7.2 17.5 9.8 17.7 12 19c2.2-1.3 4.8-1.5 7.5-1V4.9C16.8 4.4 14.2 4.6 12 6z"/><line x1="12" y1="6" x2="12" y2="19"/></svg>`,
  wsc:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M12 7c-1.8-1.1-3.8-1.3-6-.9v11c2.2-.4 4.2-.2 6 .9 1.8-1.1 3.8-1.3 6-.9v-11c-2.2-.4-4.2-.2-6 .9z"/><line x1="12" y1="7" x2="12" y2="18"/></svg>`,
  bco:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><line x1="12" y1="4" x2="12" y2="20"/><line x1="7" y1="20" x2="17" y2="20"/><path d="M12 5 5.5 7.5M12 5l6.5 2.5"/><path d="M5.5 7.5 3 13a2.5 2.5 0 0 0 5 0z"/><path d="M18.5 7.5 16 13a2.5 2.5 0 0 0 5 0z"/></svg>`,
};
const HOME_DESC = {
  wcf:"The foundational doctrinal standard.",
  wlc:"The fuller exposition, for teaching and study.",
  wsc:"Concise instruction, for learning by heart.",
  bco:"Government, Discipline, and Worship.",
};
/* Named icon set a book pack can reference by name, e.g. {"icon":"gavel"}. Same line-art
   style as the built-ins; no external dependency, works offline. (A pack may instead give an
   emoji like "⚖️", or raw inline "<svg>…</svg>".) */
const ICONS = {
  book:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="5" y="3" width="14" height="18"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/></svg>`,
  scroll:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M7 3h10v14a3 3 0 0 1-3 3H7"/><path d="M7 20a3 3 0 0 1-3-3h4"/><line x1="9.5" y1="7" x2="14.5" y2="7"/><line x1="9.5" y1="11" x2="14.5" y2="11"/></svg>`,
  gavel:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M13.5 3l7.5 7.5-2.5 2.5-7.5-7.5z"/><line x1="12" y1="8" x2="4.5" y2="15.5"/><line x1="3" y1="21" x2="11" y2="21"/></svg>`,
  scales:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><line x1="12" y1="3" x2="12" y2="21"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="5" y1="6" x2="19" y2="6"/><path d="M5 6l-2.5 5a2.5 2.5 0 0 0 5 0z"/><path d="M19 6l-2.5 5a2.5 2.5 0 0 0 5 0z"/></svg>`,
  church:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="10" y1="4" x2="14" y2="4"/><path d="M5 21V11l7-5 7 5v10"/><line x1="4" y1="21" x2="20" y2="21"/><rect x="10" y="15" width="4" height="6"/></svg>`,
  building:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><line x1="3" y1="21" x2="21" y2="21"/><path d="M5 21V9l7-4 7 4v12"/><line x1="9" y1="13" x2="9" y2="21"/><line x1="15" y1="13" x2="15" y2="21"/><line x1="12" y1="13" x2="12" y2="21"/></svg>`,
  people:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="9" cy="8" r="3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0"/><circle cx="17.5" cy="9" r="2.2"/><path d="M15 20a4.5 4.5 0 0 1 6.5-3.7"/></svg>`,
  shield:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M12 3l7 3v5c0 4.5-3 7.6-7 9-4-1.4-7-4.5-7-9V6z"/></svg>`,
  cross:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><line x1="12" y1="3" x2="12" y2="21"/><line x1="7" y1="9" x2="17" y2="9"/></svg>`,
};
function resolveIcon(c){                          // pack-supplied icon -> SVG/glyph, else default
  const ic = c && c.icon;
  if(ic){
    if(ICONS[ic]) return ICONS[ic];
    if(/^\s*<svg/i.test(ic)) return ic;           // raw inline SVG
    if([...ic.trim()].length <= 2) return `<span class="hglyph">${ic}</span>`;   // emoji
  }
  return HOME_ICONS.bco;
}
/* ── URL routing: hash reflects the current location so it's linkable + survives reload ── */
// Each visit is a page, a panel over a page, or one match in a search.
// The public fragment identifies the passage. Private search state lives in the tab's history.
let visit=null, backPending=false;
const visited=new Map();
const noteDrafts=new WeakMap();
const byId=id=>document.getElementById(id);
const visitKey=()=>crypto.randomUUID?.() || Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
function visitLabel(place){
  if(place.panel==='search') return 'search results';
  if(place.panel==='drawer') return (COMPONENTS[current]?.abbr||current)+' '+provisionLabel(current,place.drawer.ref);
  if(place.panel==='packs') return 'Packs & Notes';
  if(!place.route) return 'Home';
  if(place.route==='about') return 'About & Sources';
  const [book,ref]=place.route.split('/');
  return (COMPONENTS[book]?.abbr||book)+' '+(ref||'contents');
}
function fragment(){
  try{ return decodeURIComponent(location.hash.replace(/^#\/?/,'')); }catch(_){ return ''; }
}
function searchPosition(){
  return {query:byId('palInput').value, books:[...palBooks], index:palSel, top:byId('palHits').scrollTop};
}
function rememberVisit(persist){
  if(!visit) return;
  visit.y=window.scrollY;
  if(visit.panel==='search') visit.search=searchPosition();
  if(visit.panel==='drawer'){
    visit.drawer={ref:drawerRef, tab:dTab, filter:dFilter, sort:dSort, commentary:dCommSel, footnote:dFnSel, top:byId('dBody').scrollTop};
    if(dTab==='comm') visit.drawer.openSections=[...byId('dBody').querySelectorAll('details')].map(el=>el.open);
    if(dTab==='proofs') visit.drawer.verses=Array.from(byId('dBody').querySelectorAll('.vref'),(el,i)=>el.classList.contains('open')?i:-1).filter(i=>i>=0);
    const note=byId('dBody').querySelector('.note-input');
    if(note?.value) noteDrafts.set(visit,note.value); else noteDrafts.delete(visit);
  }
  if(cur.mode==='scroll' && view==='read'){
    visit.density=document.querySelector('.density [aria-pressed="true"]')?.dataset.density;
    visit.expanded=[...document.querySelectorAll('.prov.q.expanded')].map(p=>p.id);
  }
  const active=document.activeElement;
  visit.focus=active.id || null;
  visit.focusRef=active.dataset.ref || null;
  // Native Back has already changed history.state when popstate fires. Keep the
  // departing view here so Forward can still recover its last scroll and selection.
  visited.set(visit.key,visit);
  if(visited.size>128) visited.delete(visited.keys().next().value);
  if(persist) history.replaceState(visit,'');
}
function writeVisit(next, replace=false){
  rememberVisit(true);
  const previous=visit;
  if(next.panel && !next.match && next.route===previous.route){
    next.density=previous.density;
    next.expanded=previous.expanded;
  }
  visit={...next,readerVisit:1,key:replace?previous.key:visitKey(),back:replace?previous.back:true,
    backLabel:replace?previous.backLabel:visitLabel(previous)};
  const url=visit.route?'#'+visit.route:location.pathname+location.search;
  history[replace?'replaceState':'pushState'](visit,'',url);
  displayVisit(previous);
}
function navigatePage(route, target){
  if(visit.panel==='menu' && visit.route===route && !target){ readerBack(); return; }
  if(visit.route===route && !visit.panel && !visit.match && !target) return;
  writeVisit({route,target},visit.panel==='menu');
}
function openPanel(panel,drawer){
  if(visit.panel===panel && (!drawer || drawer.ref===drawerRef)) return;
  writeVisit({route:visit.route,target:visit.target,panel,drawer,y:window.scrollY},visit.panel==='menu');
}
function readerBack(){
  if(visit.back && !backPending){ backPending=true; history.back(); }
}
function dismissPanel(){
  if(visit.match && visit.panel==='drawer'){
    // Close exposes the full passage. Back still goes directly to the results.
    writeVisit({...visit,panel:null,drawer:null,y:window.scrollY},true);
  }else if(visit.panel) readerBack();
}
function restoreVisit(state){
  const previous=visit;
  if(previous) rememberVisit(false);
  backPending=false;
  visit=state?.readerVisit===1 ? visited.get(state.key)||state
    : {readerVisit:1,key:visitKey(),route:fragment(),back:!!previous,backLabel:previous && visitLabel(previous)};
  if(visit.panel==='search' && previous?.match?.origin===visit.key){
    visit.search={...previous.match.search};
  }
  displayVisit(previous);
  history.replaceState(visit,'',visit.route?'#'+visit.route:location.pathname+location.search);
}
function displayVisit(previous){
  byId('referencePreview').close();
  closeMenu();
  hideDrawer();
  byId('palWrap').classList.remove('show');
  byId('packWrap').classList.remove('show');
  if(!previous || previous.route!==visit.route || previous.target?.anchor!==visit.target?.anchor){
    applyRoute();
  }
  if(visit.density && view==='read' && cur.mode==='scroll'){
    byId('doc').className='doc cat-'+visit.density;
    document.querySelectorAll('.density button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.density===visit.density));
    const expanded=new Set(visit.expanded);
    document.querySelectorAll('.prov.q').forEach(p=>p.classList.toggle('expanded',expanded.has(p.id)));
  }
  const back=byId('readerBack');
  back.hidden=!visit.back || !!visit.match;
  back.title=visit.backLabel?'Back to '+visit.backLabel:'Back';
  back.setAttribute('aria-label',back.title);
  if(visit.panel==='menu'){
    byId('mobileMenu').classList.add('open');
    byId('hamburger').setAttribute('aria-expanded','true');
    byId('hamburger').setAttribute('aria-label','Close menu');
    byId('hamburger').focus({preventScroll:true});
  }
  if(visit.panel==='drawer') showDrawer(visit.drawer);
  if(visit.panel==='packs'){
    renderPacks(); byId('packWrap').classList.add('show'); byId('packClose').focus({preventScroll:true});
  }
  if(visit.panel==='search'){
    byId('palWrap').classList.add('show');
    restoreSearch(visit.search);
    byId('palInput').focus({preventScroll:true});
  }else if(visit.match) restoreSearch(visit.match.search);
  renderMatchNav();
  if(Number.isFinite(visit.y)) window.scrollTo(0,visit.y);
  if(!visit.panel){
    const trigger=byId(visit.focus) || (visit.focusRef && byId('p-'+visit.focusRef)?.querySelector('.n'));
    if(trigger) trigger.focus({preventScroll:true});
    else if(document.activeElement.closest('#drawer,#palWrap,#packWrap')) (back.hidden?byId('brand'):back).focus({preventScroll:true});
  }
}
function pagedRoute(book, rest){
  if(book === 'wcf'){
    const match = /^(\d+)\s*(?:\.|[-\u2010\u2011\u2012\u2013\u2014\u2212])\s*(\d+)(?:\s*(?:\.\s*[A-Za-z]|\(\s*[A-Za-z]\s*\)))?$/i.exec(rest);
    if(match){
      const chapter = String(Number(match[1]));
      const section = chapter + '.' + String(Number(match[2]));
      return {ch:chapter, anchor:section};
    }
  }
  if(officialSupplements.has(book)){
    const {map, order} = pagedData(book);
    if(Object.hasOwn(map,rest)) return {ch:rest};
    const ch = order.find(id=>map[id].sections.some(s=>s.ref===rest));
    if(ch) return {ch,anchor:rest};
  }
  if(book !== 'bco'){
    const match = /^(\d+)(?:-(\d+))?(?:\.[A-Za-z0-9]+|\([A-Za-z0-9]+\))?$/i.exec(rest);
    return {ch: match ? String(Number(match[1])) : rest, anchor: match && match[2] ? String(Number(match[1]))+'-'+String(Number(match[2])) : undefined};
  }
  const match = /^(\d+)-(\d+)(?:\.[A-Za-z]|\([A-Za-z]\))?$/i.exec(rest);
  if(!match) return {ch:rest};
  const chapter = String(Number(match[1]));
  const section = chapter + '-' + String(Number(match[2]));
  return {ch:chapter, anchor:section};
}
function applyRoute(){
  const raw = visit.route;
  if(!raw){ showHome(); return; }
  if(raw === 'about'){ showAbout(); return; }
  const i = raw.indexOf('/');
  const book = i < 0 ? raw : raw.slice(0, i);
  const rest = i < 0 ? '' : raw.slice(i + 1);
  if(!COMPONENTS[book]){
    const bundled = (window.BUNDLED_PACKS||[]).find(p=>p.kind==='book' && p.component && p.component.key===book);
    if(bundled){ registerBook(bundled); saveBooks(); SEARCH=null; refreshNav(); }
  }
  if(!COMPONENTS[book]){ Object.assign(visit,{route:'',target:null,panel:null,match:null}); showHome(); return; }
  if(!rest){
    if(book==='bco-subject-index') openTarget(book,{ch:'subjects'});
    else if(book==='incorporation') openTarget(book,{ch:'certificate'});
    else showComponent(book);
    return;
  }
  if(visit.target) openTarget(book, visit.target);
  else if(COMPONENTS[book].mode === 'scroll') openTarget(book, {anchor: rest});
  else openTarget(book, pagedRoute(book, rest));
}

const ENGLISH_BCO_EDITION = window.BCO_ENGLISH_EDITION;

function englishBcoEditionLine(){
  return ENGLISH_BCO_EDITION
    ? `English Book of Church Order through the ${ENGLISH_BCO_EDITION.assembly} (${ENGLISH_BCO_EDITION.year})`
    : 'English Book of Church Order';
}

function activeBcoEditionLine(){
  return BCO_EDITION.lang==='en' ? englishBcoEditionLine() : BCO_EDITION.label;
}

function showAbout(){
  setView("about");
  document.getElementById('doc').removeAttribute('lang');
  document.getElementById('doc').innerHTML = `<div class="landing about">
    <a class="back" data-home>‹ The PCA Constitution</a>
    <h1 class="about-title">About &amp; Sources</h1>
    <p class="about-lead">A study reader for the Constitution of the Presbyterian Church in America — the Westminster Standards and the Book of Church Order — with each provision linked to the General Assembly actions that have cited it.</p>

    <h2 class="about-h">Edition &amp; currency</h2>
    <ul class="about-list">
      <li><b>${englishBcoEditionLine()}</b>, including the Preface, Preliminary Principles, and Appendices.${ENGLISH_BCO_EDITION ? ` Verified against the <a href="${ENGLISH_BCO_EDITION.source}">official ${ENGLISH_BCO_EDITION.year} edition (PDF)</a>.` : ''}</li>
      ${bcoTranslations().map(pack=>`<li><b>${pack.component.name||pack.label}</b>. ${pack.notice||''}</li>`).join('')}
      <li><b>Westminster Confession &amp; Catechisms</b> — the American revision, as received in <b>1788</b> (the text held by the PCA), presented with the Scripture proof texts.</li>
    </ul>

    <h2 class="about-h">Sources</h2>
    <ul class="about-list">
      <li><b>Westminster Standards &amp; proofs</b> — public domain; the American revision as received in 1788, with the PCA's official proof-text selection.</li>
      <li><b>Scripture text</b> — verses shown in proof texts and inline previews are from the <b>Berean Standard Bible</b> (BSB), bereanbible.com, dedicated to the public domain.</li>
      <li><b>Book of Church Order</b> — © The Office of the Stated Clerk of the General Assembly of the PCA, all rights reserved. Included here for personal study; permission for wider use is being sought.</li>
      <li><b>General Assembly records</b> — drawn from the PCA <i>Minutes of the General Assembly</i> (cases, overtures, constitutional inquiries, Church Care and Discipleship Committee advice, and Review-of-Presbytery-Records exceptions) and linking to the source. BCO pages show high-confidence matches only.</li>
      <li><b>Commentary</b> — Ramsay's public-domain exposition is included; other commentaries load as separate import packs, to keep copyrighted text out of the app.</li>
    </ul>

    <h2 class="about-h">How citations work</h2>
    <p class="about-p">A small numbered marker beside a provision shows how many General Assembly records are linked to it. Tap the provision to see each included record, its year, disposition, and source. BCO pages show high-confidence matches only.</p>

    <p class="about-disclaimer">Not affiliated with, sponsored by, or endorsed by the Presbyterian Church in America. If you hold rights in any included material and would like it removed, it will be taken down immediately.</p>
  </div>`;
  window.scrollTo(0,0);
}

function showHome(){
  setView("home"); current="bco";
  document.getElementById('doc').removeAttribute('lang');
  document.querySelectorAll('#books button').forEach(b=>b.setAttribute('aria-current', false));
  const entry = k => {
    const c = COMPONENTS[k];
    return `<a class="hentry" data-book="${k}"><span class="hicon">${HOME_ICONS[k]||resolveIcon(c)}</span><span class="hname">${c.name}</span><span class="hdesc">${HOME_DESC[k]||c.tag||''}</span></a>`;
  };
  const added = window.BOOK_PACKS.map(b=>b.component.key);
  const addedByDivision = added.reduce((groups,key)=>{
    const division=(COMPONENTS[key]||{}).division||'local';
    (groups[division]||(groups[division]=[])).push(key); return groups;
  },{});
  const addedSection = Object.entries(addedByDivision).map(([division, keys])=>{
    const supplementary=division==='supplemental';
    return `<div class="home-added"><p class="division-h">${(DIVISIONS[division]||DIVISIONS.local).label}</p><p class="home-added-note">${supplementary?'Current supplementary PCA material — not part of the Constitution.':'Added by you — local governing documents, not part of the Constitution.'}</p><div class="hentries">${keys.map(entry).join('')}</div></div>`;
  }).join('');
  document.getElementById('doc').innerHTML = `<div class="landing home">
    <p class="home-eyebrow">The Standards of the</p>
    <h1 class="home-title">The Constitution of the Presbyterian Church in America</h1>
    <div class="home-rule"></div>
    <p class="home-subordinate">Subject to and subordinate to the Scriptures of the Old and New Testaments, the inerrant Word of God.</p>
    <button class="home-jump" id="homeJump"><span><span class="mag">⌕</span>&nbsp; Search the Constitution and supplementary documents — try “chief end,” presbytery, or BCO 24-1…</span></button>
    <div class="hentries">${entry('wcf')}${entry('wlc')}${entry('wsc')}${entry('bco')}</div>
    ${addedSection}
    <p class="home-edition">${activeBcoEditionLine()} · Westminster Standards in the American revision (received 1788) · <a class="home-about" data-about>About &amp; sources</a></p>
  </div>`;
  window.scrollTo(0,0);
}

function showComponent(book){
  setView("component"); current=book;
  document.querySelectorAll('#books button').forEach(b=>b.setAttribute('aria-current', b.dataset.book===book));
  const c = COMPONENTS[book];
  let toc = '';
  if(book==="wcf"){
    toc = `<h2 class="toc-h">Contents</h2><ol class="toc">` + WCF_CH.map((t,i)=>{
      const n=i+1, sample = (n===21 && !window.WCF);
      return `<li><a data-book="wcf" data-ch="${n}" data-title="${t}"><span class="tn">${n}</span><span class="tt">${t}</span>${sample?'<span class="sample">sample</span>':''}</a></li>`;
    }).join('') + `</ol>`;
  } else if(book==="wsc"||book==="wlc"){
    const secs = book==="wsc"?WSC_SECTIONS:WLC_SECTIONS;
    toc = `<h2 class="toc-h">Movements</h2><ol class="toc one">`
      + `<li><a data-book="${book}" data-qstart="1" data-qend="${book==='wsc'?107:196}" data-title="From the beginning"><span class="tn">Q1</span><span class="tt">Read from the beginning</span></a></li>`
      + secs.map(([a,b,t])=>
        `<li><a data-book="${book}" data-qstart="${a}" data-qend="${b}" data-title="${t}"><span class="tn">Q${a}–${b}</span><span class="tt">${t}</span></a></li>`
      ).join('') + `</ol>`;
  } else if(c.custom){ // custom book pack — flat chapter list
    const pd = pagedData(book);
    toc = `<h2 class="toc-h">Contents</h2><ol class="toc one">`
      + (pd ? pd.order.map(id=>{ const bc=pd.map[id]||{};
          return `<li><a data-book="${book}" data-ch="${id}"><span class="tn">${id}</span><span class="tt">${bc.title||('Chapter '+id)}</span></a></li>`;
        }).join('') : '')
      + `</ol>`;
  } else if(BCO_DATA){ // bco — real TOC: front matter, the three parts, appendices
    const partLabels = BCO_EDITION.component.parts || {};
    const GROUPS = [['front',partLabels.front||'Preface & Principles'],['fog',partLabels.fog||'Form of Government'],['rod',partLabels.rod||'Rules of Discipline'],['dow',partLabels.dow||'Directory for the Worship of God'],['appx',partLabels.appx||'Appendices']];
    toc = GROUPS.map(([key,label])=>{
      const ids = window.BCO_ORDER.filter(id=>BCO_DATA[id].part===key);
      if(!ids.length) return '';
      const numbered = key==='fog'||key==='rod'||key==='dow';
      const range = numbered ? `<p class="prange">Chapters ${ids[0]}–${ids[ids.length-1]}${key==='dow'?' · mixed authority (binding sections marked)':''}</p>` : '';
      return `<div class="part-block"><h3>${label}</h3>${range}
        <ol class="toc one">${ids.map(id=>{ const bc=BCO_DATA[id];
          return `<li><a data-book="bco" data-ch="${id}"><span class="tn">${numbered?id:''}</span><span class="tt">${bc.title||'(Vacated)'}</span>${bc.vacated?'<span class="sample">vacated</span>':''}</a></li>`;
        }).join('')}</ol></div>`;
    }).join('');
    const indexLink = officialSupplements.has('bco-subject-index')
      ? 'data-book="bco-subject-index"'
      : 'href="https://www.pcaac.org/book-of-church-order/index/"';
    toc += `<div class="part-block"><h3>Index</h3><ol class="toc one"><li><a ${indexLink}><span class="tt">BCO subject index</span></a></li></ol></div>`;
  } else { // bco fallback (illustrative)
    toc = BCO_PARTS.map(p=>`<div class="part-block">
      <h3>${p.name}</h3><p class="prange">${p.range}${p.note?` — <em>${p.note}</em>`:''}</p>
      <ol class="toc one">${p.chapters.map(ch=>{
        const sample = ch[2];
        return `<li><a data-book="bco" data-part="${p.key}" data-ch="${ch[0]}" data-title="${ch[1]}"><span class="tn">${ch[0]}</span><span class="tt">${ch[1]}</span>${sample?'<span class="sample">sample</span>':''}</a></li>`;
      }).join('')}</ol></div>`).join('');
  }
  const docEl=document.getElementById('doc');
  if(book==='bco') docEl.lang=BCO_EDITION.lang; else docEl.removeAttribute('lang');
  docEl.innerHTML = `<div class="landing component">
    <a class="back" data-home>‹ The PCA Constitution</a>
    <p class="comp-eyebrow">${DIVISIONS[c.division]?DIVISIONS[c.division].one:'Church Order'}</p>
    <h1 class="comp-title">${c.name}</h1>
    <p class="comp-lede">${c.lede}</p>
    <p class="comp-meta">${c.meta}</p>
    ${toc}
    <p class="comp-note">${
      (book==='bco'&&BCO_DATA)
      ? `Full Book of Church Order${BCO_EDITION.lang==='en'?'':' · '+BCO_EDITION.label} — for personal study only (© PCA; not for redistribution). The Directory for Worship marks its binding (constitutional) sections.`
      : ((book==='wsc'&&window.WSC)||(book==='wlc'&&window.WLC)||(book==='wcf'&&window.WCF))
      ? 'Full text — public-domain OPC edition (the standard the PCA has adopted). Scripture proof texts are pending a proof-text source (WCF 21 shows a sample).'
      : c.custom
      ? (c.nonConstitutional ? 'Supplementary PCA material.' : 'Imported document — added from a pack and stored on this device; a local governing document, not part of the PCA Constitution.')
      : c.mode==='scroll'
      ? 'Design prototype — placeholder text. The catechism opens as one long-scrolling page; every question is individually anchored and deep-linkable.'
      : 'Design prototype — text is placeholder and the chapter list is illustrative. The chapter marked “sample” opens a live reading view.'}</p>
    ${officialSupplements.has(book)?`<p class="comp-note"><a href="${esc(officialSupplements.get(book).notice.slice('Official PCA source: '.length))}">Official PCA source</a></p>`:''}
    ${book==='bco'&&BCO_EDITION.notice?`<div class="advisory-note"><strong>${BCO_EDITION.component.noticeLabel||'Edition note'}:</strong> ${BCO_EDITION.notice}</div>`:''}
  </div>`;
  window.scrollTo(0,0);
}

/* route to the right renderer based on the component's reading mode */
function openTarget(book, o){
  o = o || {};
  if(COMPONENTS[book].mode==='scroll') renderCatechism(book, o.anchor || (o.qStart!=null ? 'Q.'+o.qStart : null));
  else showChapter(book, o);
}
function markBook(book){ document.querySelectorAll('#books button').forEach(b=>b.setAttribute('aria-current', b.dataset.book===book)); }

/* ── catechism: one long-scroll page, every question anchored & deep-linkable ── */
function renderCatechism(book, anchor){
  setView("read"); current=book; cur={book, mode:'scroll'};
  markBook(book);
  const c = COMPONENTS[book];
  const DATA = (book==='wsc' && window.WSC) ? window.WSC : (book==='wlc' && window.WLC) ? window.WLC : null;   // real content where sourced
  const N = DATA ? DATA.length : (book==='wsc' ? 107 : 196);
  const secs = book==='wsc' ? WSC_SECTIONS : WLC_SECTIONS;
  const startTitle = {}; secs.forEach(([a,b,t])=>startTitle[+a]=t);
  // rail = movement jump-index (scrollspy-highlighted)
  document.getElementById('rail').innerHTML =
    `<a class="rail-back" data-book="${book}">‹ ${c.abbr} contents</a><p class="crumb">Movements</p><ol class="sub">` +
    secs.map(([a,b,t])=>`<li><a class="jump" data-spy="Q.${a}" data-anchor="Q.${a}">Q${a}–${b}</a></li>`).join('') + `</ol>`;
  // doc = whole catechism
  let doc = `<a class="read-back" data-book="${book}">‹ ${c.name}</a><p class="kicker">${c.name}</p>`
    + `<h1>${book==='wsc'?'Shorter':'Larger'} Catechism</h1><p class="subtitle">${c.tag}</p>`
    + `<div class="density" role="group" aria-label="Reading density">`
    +   `<button data-density="comfortable" aria-pressed="true">Comfortable</button>`
    +   `<button data-density="compact" aria-pressed="false">Compact</button>`
    +   `<button data-density="list" aria-pressed="false">Question list</button></div>`
    + `<div class="cat-sticky" id="catSticky"><span class="cs-q">Q. 1</span><span class="cs-m">${secs[0][2]}</span></div>`;
  let gut = '';
  for(let i=1;i<=N;i++){
    if(startTitle[i]) doc += `<h2 class="cat-movement" id="m-${i}">${startTitle[i]}</h2>`;
    const ref = "Q."+i, k = CAT_CURATED[ref], real = DATA ? DATA[i-1] : null;
    const d = dossierFor(ref), n = total(d);
    const rl = book.toUpperCase()+' '+ref;
    const inline = n>0 ? `<a class="sig-inline" data-ref="${ref}" aria-hidden="true" tabindex="-1"><span class="dot"></span>${n}</a>` : '';
    const qText = real ? real.q : (k ? k.q : '[Question '+i+']');
    const aText = real ? real.a : (k ? k.body : SHORT_LOREM);
    doc += `<div class="prov q" id="p-${ref}"><span class="body"><a class="n" data-ref="${ref}" ${nAttrs(rl,n)}>${ref}</a>${inline} ${qText}</span><span class="ans">${aText}</span></div>`;
    gut += n>0
      ? `<a class="sig" data-ref="${ref}" aria-hidden="true" tabindex="-1" title="${n} linked GA records for ${ref}"><span class="dot"></span>${n}</a>`
      : `<a class="sig empty" data-ref="${ref}" aria-hidden="true" tabindex="-1" title="No linked GA records on file"><span class="dot"></span></a>`;
  }
  const other = book==='wsc' ? 'wlc' : 'wsc';
  doc += `<nav class="pager">`
    + `<a class="pg prev pgnav" data-book="${book}" data-contents><span class="chev">‹</span><span class="pgwrap"><span class="pl">Back to</span><span class="pt">Contents</span></span></a>`
    + `<span class="pg pos">${N} questions</span>`
    + `<a class="pg next pgnav" data-book="${other}" data-contents><span class="pgwrap"><span class="pl">Also</span><span class="pt">${other==='wlc'?'Larger':'Shorter'} Catechism</span></span><span class="chev">›</span></a>`
    + `</nav>`;
  const docEl = document.getElementById('doc');
  docEl.className = 'doc cat-comfortable';
  docEl.removeAttribute('lang');
  docEl.innerHTML = doc;
  linkDocumentReferences(docEl);
  linkScriptureReferences(docEl);
  document.getElementById('gutter').innerHTML = gut;
  alignGutter();
  if(anchor && document.getElementById('p-'+anchor)){
    document.getElementById('p-'+anchor).scrollIntoView({block:'start'});
  } else { window.scrollTo(0,0); }
  docEl.classList.remove('turn'); void docEl.offsetWidth; docEl.classList.add('turn');
}

/* locate a spec within its component's spine */
function spineIndex(book, o){
  const s = SPINE[book]; if(!s) return -1;
  if(o.qStart!=null) return s.findIndex(x=>x.qStart===String(o.qStart));
  return s.findIndex(x=>x.ch===String(o.ch) && (o.part==null || x.part===o.part));
}
/* build one prev/next pager link from a spine entry */
function pgLink(kind, book, sp){
  const isQ = sp.qStart!=null;
  const data = isQ
    ? `data-qstart="${sp.qStart}" data-qend="${sp.qEnd}" data-title="${sp.title}"`
    : `${sp.part?`data-part="${sp.part}" `:''}data-ch="${sp.ch}" data-title="${sp.title}"`;
  const num = isQ ? `Q ${sp.qStart}–${sp.qEnd}` : (/^\d/.test(String(sp.ch)) ? `Ch. ${sp.ch}` : '');
  const wrap = `<span class="pgwrap"><span class="pl">${num}</span><span class="pt">${sp.title}</span></span>`;
  return kind==='prev'
    ? `<a class="pg prev pgnav" data-book="${book}" ${data}><span class="chev">‹</span>${wrap}</a>`
    : `<a class="pg next pgnav" data-book="${book}" ${data}>${wrap}<span class="chev">›</span></a>`;
}
/* move one step along the spine; bounce at component edges */
function goRelative(dir){
  if(view!=='read' || cur.mode==='scroll' || visit.panel || byId('referencePreview').open) return;
  const s = SPINE[cur.book], i = spineIndex(cur.book, cur.o), j = i + dir;
  if(i<0 || j<0 || j>=s.length){ bounce(dir); return; }
  navigatePage(cur.book+'/'+s[j].ch);
}
function bounce(){
  const d = document.getElementById('doc');
  d.classList.remove('bump'); void d.offsetWidth; d.classList.add('bump');
}

function renderBlocks(blocks, head){
  let lead='', start=0;
  if(blocks[0] && blocks[0][0]==='p' && blocks[0][1]===0){ lead=blocks[0][2]; start=1; }
  let out = `<p class="lead">${head} ${lead}</p>`;
  for(let k=start;k<blocks.length;k++){
    const b=blocks[k];
    if(b[0]==='p') out += `<p class="bpara d${b[1]}">${b[2]}</p>`;
    else out += `<div class="li d${b[1]}"><span class="mk">${b[2]}</span> ${b[3]}</div>`;
  }
  return out;
}
const REFERENCE_BOOKS=['bco','wcf','wsc','wlc','rao','omsjc'];
function documentReferenceTarget(book, ref){
  if(!REFERENCE_BOOKS.includes(book)) return;
  const component=COMPONENTS[book];
  if(!component) return;
  let target;
  if(component.mode==='scroll'){
    const number=/^Q\.(\d+)$/.exec(ref)?.[1];
    const qa=window[book.toUpperCase()]?.[Number(number)-1];
    if(qa) target={question:qa.q,body:qa.a};
  }else{
    const {ch,anchor}=pagedRoute(book,ref);
    const chapter=book==='wcf' ? window.WCF?.[ch] : pagedData(book)?.map[ch];
    if(chapter && !chapter.vacated){
      if(anchor===ref){
        const sections=(chapter.sections||[]).filter(section=>section.ref===ref);
        if(sections.length===1) target=sections[0];
      }else if(ch===ref && (/^\d+$/.test(ref) || (book==='bco' && /^pref-[1-3]$/.test(ref)))){
        target={chapter:ch};
      }
    }
  }
  if(target && (target.chapter || target.blocks?.length || target.body?.trim())){
    const label=book==='bco' ? ({es:'LDO',ko:'교회헌법'}[BCO_EDITION.lang]||'BCO') : component.abbr;
    return {...target, title:label+(/^pref-[1-3]$/.test(ref) ? ' Preface '+['I','II','III'][Number(ref.at(-1))-1] : (target.chapter?' chapter ':' ')+ref), lang:book==='bco'?BCO_EDITION.lang:'en'};
  }
}
function linkDocumentReferences(doc){
  const aliases=new Map();
  for(const book of REFERENCE_BOOKS){
    const component=COMPONENTS[book];
    if(!component) continue;
    const names=[component.abbr,component.name,...({
      bco:['BCO','LDO','교회헌법','Book of Church Order'],
      wcf:['Westminster Confession'],wsc:['Shorter Catechism'],wlc:['Larger Catechism'],
    }[book]||[])];
    for(const name of names.filter(Boolean)){
      const key=name.toLowerCase();
      if(aliases.has(key) && aliases.get(key)!==book) aliases.set(key,null);
      else aliases.set(key,book);
    }
  }
  const prefixes=[...aliases.keys()].sort((a,b)=>b.length-a.length)
    .map(name=>name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
  // Require a document name and a complete reference. Leave ranges and unsupported subpoints as text.
  const citation=new RegExp(
    String.raw`(?<![\p{L}\p{N}_])(${prefixes})\s+((?:Preface,?\s+(?:III|II|I)|Q\.?\s*\d+|(?:\d+|[A-Z]+)[.:‑–-]\d+[a-z]?(?:\.[a-z0-9]+)*(?:\([a-z0-9]+\))?|\d+))(?![\w:‑–—-]|\.[a-z0-9]|\s*\([a-z0-9]+\)|\s*(?:[-‑–—]|through\b|to\s+\d))`,
    'giu'
  );
  const walker=document.createTreeWalker(doc,NodeFilter.SHOW_TEXT);
  const nodes=[];
  while(walker.nextNode()){
    const node=walker.currentNode;
    if(node.parentElement.closest('.prov .body,.prov .ans') && !node.parentElement.closest('a,sup')) nodes.push(node);
  }
  let index=0;
  for(const node of nodes){
    const previous=node.previousSibling;
    // The source often italicizes the abbreviation in a separate element.
    const abbreviation=previous?.matches?.('i,em') && aliases.has(previous.textContent.replace(/^\s*\(?\s*|\s+$/g,'').toLowerCase()) ? previous.textContent : '';
    const value=abbreviation+node.data;
    let end=0;
    const fragment=document.createDocumentFragment();
    const appendLink=(book,printedRef,label,offset)=>{
      let ref=printedRef.replace(/[‑–]/g,'-');
      if(book==='wcf') ref=ref.replace(/[:-]/,'.');
      if(book==='wsc'||book==='wlc') ref=ref.replace(/^(?:Q\.?\s*)?(\d+)$/i,'Q.$1');
      if(book==='bco'){
        const preface=/^Preface,?\s+(I{1,3})$/i.exec(ref);
        if(preface) ref='pref-'+preface[1].length;
        // A BCO item shares its provision's route. Check the marker in the displayed edition.
        const item=/^(\d+-\d+)(?:\.?([a-z])|\.(\d+)|\(([a-z]|\d+)\))$/i.exec(ref);
        if(item){
          const provision=documentReferenceTarget(book,item[1]);
          const marker=(item[2]||item[3]||item[4]).toLowerCase()+'.';
          const exists=provision?.blocks?.some(([kind,,text])=>kind==='i'
            ? text.toLowerCase()===marker
            : /^\d+\.$/.test(marker) && _plain(text).startsWith(marker+' '));
          if(!exists) return;
          ref=item[1];
        }
      }
      if(!documentReferenceTarget(book,ref)) return;
      const finish=offset+label.length-abbreviation.length;
      const start=offset<abbreviation.length ? finish-printedRef.length : offset-abbreviation.length;
      const link=document.createElement('a');
      link.id='cross-reference-'+index++;
      link.className='cross-reference';
      link.href='#'+book+'/'+encodeURIComponent(ref);
      link.setAttribute('aria-haspopup','dialog');
      link.setAttribute('aria-label',book==='bco' && label===printedRef ? 'BCO '+label : label.trim());
      link.textContent=node.data.slice(start,finish);
      fragment.append(node.data.slice(end,start),link);
      end=finish;
    };
    for(const match of value.matchAll(citation)){
      const book=aliases.get(match[1].toLowerCase());
      appendLink(book,match[2],match[0],match.index);
      // An explicit BCO citation can govern a second complete provision in the same parentheses.
      if(book==='bco' && ((abbreviation ? previous.previousSibling?.textContent||'' : '')+value.slice(0,match.index)).trimEnd().endsWith('(')){
        const next=match.index+match[0].length;
        const pair=/^\s+and\s+(\d{1,2}[-‑–]\d+[a-z]?)\s*\)/i.exec(value.slice(next));
        if(pair) appendLink(book,pair[1],pair[1],next+pair[0].indexOf(pair[1]));
      }
    }
    if(end) node.replaceWith(fragment,node.data.slice(end));
  }
}
const inlineScripture=window.INLINE_SCRIPTURE;
const scriptureLabels=Object.keys(inlineScripture?.references||{}).sort((a,b)=>b.length-a.length);
const scripturePattern=scriptureLabels.length ? new RegExp(
  String.raw`(?<![\p{L}\p{N}_])(?:${scriptureLabels.map(label=>label
    .replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/ /g,'\\s+')).join('|')})(?:(?<=절)|(?<=장)(?!\s*\d)|(?![\p{L}\p{N}_:]|\s*[:–—-]|\s*,\s*\d))`,
  'giu'
) : null;
function linkScriptureReferences(doc){
  if(!scripturePattern) return;
  const walker=document.createTreeWalker(doc,NodeFilter.SHOW_TEXT);
  const nodes=[];
  while(walker.nextNode()){
    const node=walker.currentNode;
    if(node.parentElement.closest('.prov .body,.prov .ans') && !node.parentElement.closest('a,button,sup')) nodes.push(node);
  }
  for(const node of nodes){
    const previous=node.previousSibling;
    const prefix=previous?.matches?.('i,em,b,strong') ? previous.textContent : '';
    const value=prefix+node.data;
    const fragment=document.createDocumentFragment();
    let end=0;
    for(const match of value.matchAll(scripturePattern)){
      const finish=match.index+match[0].length-prefix.length;
      if(finish<=0) continue;
      const start=Math.max(0,match.index-prefix.length);
      const button=document.createElement('button');
      button.type='button';
      button.className='scripture-reference';
      button.title='Preview Scripture';
      button.dataset.scripture=match[0].toLowerCase().replace(/\s+/g,' ');
      button.setAttribute('aria-haspopup','dialog');
      button.setAttribute('aria-label',match[0]);
      button.textContent=node.data.slice(start,finish);
      fragment.append(node.data.slice(end,start),button);
      end=finish;
    }
    if(end) node.replaceWith(fragment,node.data.slice(end));
  }
}
function showScripturePreview(trigger){
  const keys=inlineScripture.references[trigger.dataset.scripture];
  if(!keys?.length) return;
  const title=byId('referencePreviewTitle');
  title.textContent=trigger.getAttribute('aria-label');
  title.lang=byId('doc').lang||'en';
  const text=byId('referencePreviewText');
  text.lang='en';
  text.innerHTML='<div class="body"><p><small>Berean Standard Bible</small></p>'+keys.map(key=>
    '<p><strong>'+esc(key)+'</strong> '+esc(inlineScripture.verses[key])+'</p>'
  ).join('')+'</div>';
  byId('referencePreviewOpen').hidden=true;
  openReferencePreview(trigger);
}
function openReferencePreview(trigger){
  trigger.focus({preventScroll:true});
  const dialog=byId('referencePreview');
  dialog.showModal();
  dialog.scrollTop=0;
}
function showReferencePreview(link){
  const [book,ref]=decodeURIComponent(link.hash.slice(1)).split('/');
  const target=documentReferenceTarget(book,ref);
  if(!target) return;
  const title=byId('referencePreviewTitle');
  title.textContent=target.title;
  title.lang=target.lang;
  const text=byId('referencePreviewText');
  text.lang=target.lang;
  const question=target.question ? '<p><strong>'+target.question+'</strong></p>' : '';
  const provisions=target.chapter ? buildChapter(book,{ch:target.chapter}).provs : [target];
  const body=provisions.map(provision=>{
    const label=target.chapter && provision.ref ? '<strong>'+esc(provision.ref)+'.</strong>' : '';
    if(provision.blocks?.length) return renderBlocks(provision.blocks,label);
    return '<p>'+label+' '+(provision.body||'')+'</p>';
  }).join('');
  text.innerHTML='<div class="body">'+question+body+'</div>';
  byId('referencePreviewOpen').href=link.href;
  byId('referencePreviewOpen').hidden=false;
  openReferencePreview(link);
}
function renderBcoIndexRows(blocks){
  const reference = /\b(?:([0-9]{1,2}-[0-9]+)(?:\([a-z0-9]+\)|\.[a-z0-9]+|[a-z])?|appendix\s+([a-j])\b|appendices\s+([a-j](?:(?:,\s*|\s+and\s+|,\s*and\s+)[a-j]\b)*)\b|preface\s+(iii|ii|i|[1-3])\b|chapter\s+(\d{1,2})\b)/gi;
  const link = (label, route) => route
    ? `<a href="#bco/${route}" class="bco-index-link">${label}</a>`
    : label;
  return blocks.map(([kind,depth,marker,body])=>{
    const text = kind==='i' ? marker+' '+body : marker;
    const first = text.search(reference);
    const topic = first<0 ? text : text.slice(0,first).trimEnd();
    const refs = first<0 ? '' : text.slice(first).replace(reference,(label,section,appendix,appendices,preface,chapter)=>{
      if(section){
        const id = section.split('-')[0];
        return link(label, !BCO_DATA[id]?.vacated && BCO_DATA[id]?.sections?.some(s=>s.ref===section) ? section : '');
      }
      const appendixRoute = letter => {
        const id = 'app'+letter.toUpperCase();
        return BCO_DATA[id] && !BCO_DATA[id].vacated ? id : '';
      };
      if(appendices) return label.slice(0,-appendices.length)+appendices.replace(/\b[A-J]\b/gi, letter=>link(letter,appendixRoute(letter)));
      if(appendix) return link(label,appendixRoute(appendix));
      const id = preface ? 'pref-'+({i:1,ii:2,iii:3}[preface.toLowerCase()]||preface) : chapter;
      return link(label,BCO_DATA[id] && !BCO_DATA[id].vacated ? id : '');
    });
    return `<div class="bco-index-row bpara d${depth}"><span class="bco-index-topic">${topic}</span>${refs?`<span class="bco-index-refs">${refs}</span>`:''}</div>`;
  }).join('');
}
function showChapter(book, o){
  setView("read"); current=book; cur={book,o};
  document.querySelectorAll('#books button').forEach(b=>b.setAttribute('aria-current', b.dataset.book===book));
  const ch = buildChapter(book, o);
  const c = COMPONENTS[book];
  const isBcoIndex = book==='bco-subject-index';
  const isCertificate = book==='incorporation';
  const directRead = isBcoIndex || isCertificate;
  const contentsBook = isBcoIndex ? 'bco' : isCertificate ? '' : book;
  const contentsName = isBcoIndex ? 'BCO contents' : isCertificate ? 'The PCA Constitution' : c.name;
  const railContentsName = isCertificate ? contentsName : COMPONENTS[contentsBook].abbr+' contents';
  const sourceUrl = directRead ? officialSupplements.get(book)?.notice.slice('Official PCA source: '.length) : '';
  // rail
  let rail = `<a class="rail-back" data-book="${contentsBook}">‹ ${railContentsName}</a><p class="crumb">${ch.title}</p>`;
  if(ch.railSub && ch.railSub.length) rail += `<ol class="sub">` + ch.railSub.map(r=>`<li><a class="jump" data-anchor="${r}">${provisionLabel(book,r)}</a></li>`).join('') + `</ol>`;
  document.getElementById('rail').innerHTML = rail;
  // doc
  let doc = `<a class="read-back" data-book="${contentsBook}">‹ ${contentsName}</a>`
    + `<p class="kicker">${ch.kicker}</p><h1>${ch.title}</h1>`
    + (sourceUrl ? `<p class="subtitle">${esc(c.meta)} · <a href="${esc(sourceUrl)}">Official PCA source</a></p>` : '')
    + (ch.subtitle ? `<p class="subtitle">${ch.subtitle}</p>` : '')
    + (ch.advisoryNote ? `<div class="advisory-note">${ch.advisoryNote}</div>` : '')
    + (book==='bco' ? `<div id="chapterCommentary">${chapterCommentaryHtml(o.ch)}</div>` : '');
  let gut = '';
  ch.provs.forEach(p=>{
    if(p.prose || !p.ref){
      const proseBody = p.blocks ? (book==='bco-subject-index' ? renderBcoIndexRows(p.blocks) : renderBlocks(p.blocks, '')) : (p.body||'');
      const id = p.ref ? ` id="p-${p.ref}"` : '';
      if(proseBody) doc += `<div class="prov prose"${id}><div class="body">${proseBody}</div></div>`;
      else if(id) doc += `<div${id}></div>`;
      return;
    }  // prose (front/appendix); keep id if it has footnotes
    const d = dossierFor(p.ref), n = total(d);
    const label = provisionLabel(book,p.ref);
    const rl = (book==='bco'?'BCO ':book.toUpperCase()+' ')+label;
    const inline = n>0 ? `<a class="sig-inline" data-ref="${p.ref}" aria-hidden="true" tabindex="-1"><span class="dot"></span>${n}</a>` : '';
    const tag = (p.con===true)?`<span class="ptag bind">[ BINDING ]</span>`:'';
    if(ch.q){
      doc += `<div class="prov q" id="p-${p.ref}"><span class="body"><a class="n" data-ref="${p.ref}" ${nAttrs(rl,n)}>${p.ref}</a>${inline}${tag} ${p.q}</span><span class="ans">${p.body}</span></div>`;
    } else if(p.blocks){
      const head = `<a class="n" data-ref="${p.ref}" ${nAttrs(rl,n)}>${label}.</a>${inline}${tag}`;
      doc += `<div class="prov${p.con===true?' binding':''}" id="p-${p.ref}"><div class="body">${renderBlocks(p.blocks, head)}</div></div>`;
    } else {
      doc += `<div class="prov${p.con===true?' binding':''}" id="p-${p.ref}"><span class="body"><a class="n" data-ref="${p.ref}" ${nAttrs(rl,n)}>${label}.</a>${inline}${tag} ${p.body}</span></div>`;
    }
    gut += n>0
      ? `<a class="sig" data-ref="${p.ref}" aria-hidden="true" tabindex="-1" title="${n} linked GA records for ${label}"><span class="dot"></span>${n}</a>`
      : `<a class="sig empty" data-ref="${p.ref}" aria-hidden="true" tabindex="-1" title="No linked GA records on file"><span class="dot"></span></a>`;
  });
  // footer pager (sequential nav) — flows across BCO parts, stops at component edges
  const s = SPINE[book], i = spineIndex(book, o);
  const prev = i>0 ? s[i-1] : null, next = (i>=0 && i<s.length-1) ? s[i+1] : null;
  if(!directRead) doc += `<nav class="pager">`
    + (prev ? pgLink('prev', book, prev) : `<a class="pg prev disabled pgnav" data-book="${book}" data-contents>‹ Contents</a>`)
    + `<span class="pg pos">${i>=0?i+1:'—'} / ${s.length}</span>`
    + (next ? pgLink('next', book, next) : `<a class="pg next disabled pgnav" data-book="${book}" data-contents>Contents ›</a>`)
    + `</nav><p class="swipe-hint">Swipe ‹ › to turn the page</p>`;

  const docEl = document.getElementById('doc');
  docEl.className = 'doc';   // clear any catechism density class
  if(book==='bco') docEl.lang=BCO_EDITION.lang; else docEl.removeAttribute('lang');
  docEl.innerHTML = doc;
  linkDocumentReferences(docEl);
  linkScriptureReferences(docEl);
  document.getElementById('gutter').innerHTML = gut;
  if(o.anchor){
    const target = document.getElementById('p-' + o.anchor);
    if(target) target.scrollIntoView({block:'start'}); else window.scrollTo(0,0);
    document.querySelectorAll('.rail .sub a').forEach(a=>a.classList.toggle('here', a.dataset.anchor===o.anchor));
    target?.classList.add('route-target');
    window.setTimeout(()=>target?.classList.remove('route-target'), 1800);
  } else window.scrollTo(0,0);
  alignGutter();
  // gentle page-turn fade
  docEl.classList.remove('turn'); void docEl.offsetWidth; docEl.classList.add('turn');
}

function alignGutter(){
  const shell = document.querySelector('.shell');
  if(!shell || view!=="read") return;
  const base = shell.getBoundingClientRect().top + window.scrollY;
  document.querySelectorAll('.gutter .sig').forEach(sig=>{
    const prov = document.getElementById('p-' + sig.dataset.ref);
    if(prov) sig.style.top = (prov.getBoundingClientRect().top + window.scrollY - base) + 'px';
  });
}
window.addEventListener('resize', alignGutter);
window.addEventListener('load', alignGutter);

/* scrollspy: highlight the movement currently at the top of the catechism scroll */
window.addEventListener('scroll', ()=>{
  if(view!=='read' || cur.mode!=='scroll') return;
  let active = null;
  document.querySelectorAll('.cat-movement').forEach(h=>{ if(h.getBoundingClientRect().top < 120) active = h.id.slice(2); });
  document.querySelectorAll('.rail .sub a').forEach(a=>a.classList.toggle('here', active!=null && a.dataset.spy==='Q.'+active));
  // sticky current-question indicator
  const sticky = document.getElementById('catSticky');
  if(sticky){
    let curRef = null;
    document.querySelectorAll('.prov.q').forEach(p=>{ if(p.getBoundingClientRect().top < 88) curRef = p.id.slice(2); });
    if(curRef){
      sticky.querySelector('.cs-q').textContent = curRef.replace('.', '. ');
      const num = +curRef.replace('Q.',''); const secs = cur.book==='wsc'?WSC_SECTIONS:WLC_SECTIONS;
      let mv = secs[0][2]; secs.forEach(([a,b,t])=>{ if(num>=+a) mv=t; });
      sticky.querySelector('.cs-m').textContent = mv;
    }
  }
}, {passive:true});

/* open a chapter from a clicked element's dataset */
function openFromEl(el){
  const book = el.dataset.book;
  navigatePage(book+'/'+(el.dataset.qstart?'Q.'+el.dataset.qstart:el.dataset.ch));
}

/* ───────────── drawer (provision dossier) ───────────── */
// authority for DfW provisions (binding = constitutional; advisory = not binding)
const AUTH = {"51-1":"advisory","51-2":"advisory","51-3":"binding","58-4":"binding"};
const TYPE_META = {case:["t-case","Judicial cases"], ov:["t-ov","Overtures"], inq:["t-inq","Inquiries"], ccb:["t-ccb","CCB advice"], rpr:["t-rpr","RPR exceptions"], pp:["t-pp","Study reports"]};
function histogram(rows){
  const dec={}; rows.forEach(r=>{ if(!r.yr) return; const d=Math.floor(r.yr/10)*10; dec[d]=(dec[d]||0)+1; });
  const ds=Object.keys(dec).map(Number).sort((a,b)=>a-b); if(!ds.length) return '';
  const max=Math.max(...ds.map(d=>dec[d]));
  return `<div class="histo"><p class="hcap">Linked GA records by decade</p>` + ds.map(d=>
    `<div class="hbar"><span class="hd">${String(d).slice(2)}s</span><span class="hbarfill" style="width:${Math.round(dec[d]/max*100)}%"></span><span>${dec[d]}</span></div>`).join('') + `</div>`;
}
function notesBlock(ref){
  const list = NOTES[ref] || [];
  const items = list.length
    ? list.map((nt,i)=>`<div class="note" id="dnote-${i}"><div class="note-meta">${nt.who} · ${nt.when}<button class="note-del" data-i="${i}" aria-label="Delete note">✕</button></div>${nt.text}</div>`).join('')
    : `<p class="note-empty">No notes yet.</p>`;
  return `<div class="notes"><p class="count">Notes <span class="note-tag">private</span></p>${items}
    <div class="note-add"><textarea class="note-input" rows="2" placeholder="Add a note…"></textarea><button class="note-save">Save note</button></div></div>`;
}

let drawerRef=null, dTab='cit', dFilter='all', dSort='desc', dCommSel=0, dFnSel=null;
/* full section content, lifted from the already-rendered provision */
function sectionNode(ref){
  const el = document.getElementById('p-'+ref);
  if(!el) return null;
  const c = el.cloneNode(true);
  c.removeAttribute('id');
  c.classList.remove('route-target');
  c.querySelectorAll('.n, .sig-inline, .ptag, sup.pf, .proofs, .pf-toggle, .pf-more').forEach(x=>x.remove());
  return c;
}
function sectionHTML(ref){
  const c = sectionNode(ref);
  if(c && c.innerHTML.trim()) return c.innerHTML;
  const fallback = (dossierFor(ref).quote||'').replace(/…\s*$/,'');
  return fallback ? `<p>${esc(fallback)}</p>` : '';
}
function sectionText(ref){
  const c = sectionNode(ref);
  if(c){
    c.querySelectorAll('.lead, .li, .bpara, .ans').forEach(x=>x.insertAdjacentText('afterend','\n'));
    const t = c.textContent
      .replace(/[ \t]+/g,' ')
      .replace(/ *\n */g,'\n')
      .replace(/\n{3,}/g,'\n\n')
      .trim();
    if(t) return t;
  }
  return (dossierFor(ref).quote||'').replace(/…\s*$/,'');
}
/* sub-points of `ref` named in a citation title, e.g. "BCO 12-5.b" -> ["b"].
   Literal match + boundary guards so RAO/other refs and partial numbers (1-3 in 11-3) don't leak. */
function citeSubpoints(ref, ttl){
  const out=[]; let i=0;
  while((i=ttl.indexOf(ref, i))!==-1){
    const before=ttl[i-1], after=i+ref.length;
    if(!(before && /[\d-]/.test(before)) && !/\d/.test(ttl[after]||'')){
      const m=/^\.?\(?([a-z])\)?(?![a-z])/.exec(ttl.slice(after));
      if(m && !out.includes(m[1])) out.push(m[1]);
    }
    i=after;
  }
  return out;
}
function spChip(ref, ttl){
  const sp=citeSubpoints(ref, ttl);
  return sp.length ? `<span class="sp-chip" title="Cites ${ref}.${sp.join(', '+ref+'.')}">${ref}.${sp.join('/')}</span>` : '';
}
function commentarySectionMeta(s){
  const qs=Array.isArray(s.questions)?s.questions.slice().sort((a,b)=>a-b):[];
  const q=qs.length>1?('Shared discussion · Q.'+qs[0]+'–'+qs[qs.length-1]):(qs.length?'Q.'+qs[0]:'');
  const r=s.questionRange, sameRange=!!(r&&qs.length&&r.from===qs[0]&&r.through===qs[qs.length-1]);
  const printed=r&&!sameRange?('Printed heading range · Q.'+r.from+(r.through===r.from?'':'–'+r.through)):'';
  const p=s.pages?('pp. '+s.pages.from+(s.pages.through===s.pages.from?'':'–'+s.pages.through)):'';
  return [q,printed,p].filter(Boolean).join(' · ');
}
function chapterCommentaryHtml(chapter){
  return window.BCO_COMMENTARIES.filter(pack=>(pack.corpus||'bco')==='bco')
    .map(pack=>{
      const content=pack.entries?.[chapter];
      return commentaryContentHasText(content)
        ? `<details class="commentary"><summary>${esc(pack.label)}</summary>${commentaryContentHtml(content)}</details>`
        : '';
    }).join('');
}
function commentaryLinksHtml(links){
  if(!Array.isArray(links)) return '';
  return links.map(link=>{
    if(typeof link?.label!=='string' || typeof link.url!=='string') return '';
    const url=URL.canParse(link.url) ? new URL(link.url) : null;
    if(url?.protocol!=='https:') return '';
    return `<p><a href="${esc(url.href)}" target="_blank" rel="noopener">${esc(link.label)}</a></p>`;
  }).join('');
}
function commentaryContentHasText(content){
  return Array.isArray(content)?content.length>0:!!(content&&
    ((Array.isArray(content.blocks)&&content.blocks.length)||(Array.isArray(content.paragraphs)&&content.paragraphs.length)||commentaryLinksHtml(content.links)));
}
const commentaryTags = new Set('a b blockquote br cite div em i li ol p small span strong sub sup u ul'.split(' '));
const escapedCommentaryTag = /(?:&lt;|&#0*60;|&#x0*3c;)\/?([a-z]+)\b[^<>]*?(?:&gt;|&#0*62;|&#x0*3e;)/gi;
function commentaryParagraphHtml(text){
  const source = document.createElement('template');
  const entity = document.createElement('template');
  source.innerHTML = String(text).replace(escapedCommentaryTag,(tag,name)=>{
    if(!commentaryTags.has(name.toLowerCase())) return tag;
    entity.innerHTML = tag;
    return entity.content.textContent;
  });
  const entry = document.createElement('div');
  entry.className = 'commentary-entry';

  function appendFormatting(parent, nodes){
    for(const node of nodes){
      if(node.nodeType===Node.TEXT_NODE){
        parent.append(node.textContent);
        continue;
      }
      if(node.nodeType!==Node.ELEMENT_NODE || node.namespaceURI!=='http://www.w3.org/1999/xhtml') continue;
      const tag = node.localName;
      if(!commentaryTags.has(tag)) continue;
      const element = document.createElement(tag);
      if(tag==='div' && node.classList.contains('commentary-footnotes')) element.className = 'commentary-footnotes';
      if(tag==='a'){
        const href = (node.getAttribute('href')||'').trim();
        if(/^(https?:\/\/|mailto:|#)/i.test(href)) element.setAttribute('href',href);
      }
      appendFormatting(element,node.childNodes);
      parent.append(element);
    }
  }

  appendFormatting(entry,source.content.childNodes);
  return entry.outerHTML;
}
function commentaryContentHtml(content){
  if(Array.isArray(content)) return content.map(commentaryParagraphHtml).join('');
  if(!content||typeof content!=='object') return '';
  const links=commentaryLinksHtml(content.links);
  const blocks=content.blocks;
  if(Array.isArray(blocks)&&blocks.length){
    return blocks.map(b=>{
      if(!Array.isArray(b)) return '';
      const depth=Math.max(0,Math.min(4,Number.isInteger(b[1])?b[1]:0));
      if(b[0]==='p') return '<p class="bpara d'+depth+'">'+esc(b[2]||'')+'</p>';
      if(b[0]==='i') return '<div class="li d'+depth+'"><span class="mk">'+esc(b[2]||'')+'</span> '+esc(b[3]||'')+'</div>';
      return '';
    }).join('')+links;
  }
  return (Array.isArray(content.paragraphs)?content.paragraphs:[]).map(commentaryParagraphHtml).join('')+links;
}
function renderCommentarySections(sections,qNumber){
  const source=Array.isArray(sections)?sections:[];
  const selected=source.filter(s=>Array.isArray(s.questions)&&s.questions.includes(qNumber));
  if(!selected.length) return '';
  const byId=new Map(source.filter(s=>s&&s.id).map(s=>[s.id,s]));
  const contextIds=new Set();
  selected.forEach(s=>{
    let id=s.parentId; const seen=new Set();
    while(id&&byId.has(id)&&!seen.has(id)){
      seen.add(id); contextIds.add(id); id=byId.get(id).parentId;
    }
  });
  const primary=selected.filter(s=>!s.id||!contextIds.has(s.id));
  const renderFocus=s=>{
    const meta=commentarySectionMeta(s), sid=s.id?' id="commentary-'+esc(s.id)+'"':'';
    return '<section class="commentary-section commentary-focus-section"'+sid+'><h4>'+esc(s.title||'Commentary section')+'</h4>'
      +(meta?'<p class="commentary-range">'+esc(meta)+'</p>':'')
      +'<div class="commentary-section-body">'+commentaryContentHtml(s)+'</div></section>';
  };
  const renderContext=s=>{
    const meta=commentarySectionMeta(s), children=source.filter(x=>x.parentId===s.id&&contextIds.has(x.id));
    const sid=s.id?' id="commentary-'+esc(s.id)+'"':'';
    return '<details class="commentary-context-node"'+sid+'><summary><span>'+esc(s.title||'Hodge section')+'</span>'
      +(meta?'<small>'+esc(meta)+'</small>':'')+'</summary><div class="commentary-context-body">'
      +commentaryContentHtml(s)+children.map(renderContext).join('')+'</div></details>';
  };
  const roots=Array.from(contextIds).map(id=>byId.get(id)).filter(s=>s&&!contextIds.has(s.parentId));
  const context=roots.length?'<details class="commentary-context"><summary>Context in Hodge’s book ('+roots.length+' section'+(roots.length===1?'':'s')+')</summary>'
      +'<div class="commentary-context-list">'+roots.map(renderContext).join('')+'</div></details>':'';
  return primary.map(renderFocus).join('')+context;
}
function renderDrawer(packLabel){
  const ref=drawerRef, d=dossierFor(ref), n=total(d);
  const isCustom = !!(COMPONENTS[current] && COMPONENTS[current].custom);
  const refLabel=(COMPONENTS[current].abbr||current.toUpperCase())+' '+provisionLabel(current,ref);
  document.getElementById('dEyebrow').textContent = COMPONENTS[current].name;
  document.getElementById('dRef').textContent = refLabel;
  document.getElementById('dQuote').textContent = '';
  const auth = AUTH[ref];
  document.getElementById('dMeta').innerHTML =
    (auth ? `<span class="auth-pill ${auth}">${auth==='binding'?'Binding · constitutional':'Advisory'}</span>` : '')
    + `<button class="copy-cite" data-cite="${refLabel}">⧉ Copy citation</button>`
    + `<button class="copy-cite" data-copytext="1" data-cite="${refLabel}">⧉ Copy section text</button>`;
  const hasHist = d.amend && d.amend.length;
  const qMatch=/^Q\.(\d+)$/.exec(ref), qNumber=qMatch?Number(qMatch[1]):null;
  const comms = window.BCO_COMMENTARIES                       // commentary packs targeting THIS corpus
      .filter(c=>(c.corpus||'bco')===current)
      .map(c=>{
        const content=c.entries&&c.entries[ref];
        return {label:c.label,content,
          sections:qNumber===null?[]:(c.sections||[]).filter(s=>Array.isArray(s.questions)&&s.questions.includes(qNumber))};
      })
      .filter(c=>commentaryContentHasText(c.content)||c.sections.length);
  const bp = isCustom ? window.BOOK_PACKS.find(b=>b.component.key===current) : null;
  const fnotes = (bp && bp.footnotes && bp.footnotes[ref]) || null;   // the book's own footnotes for this provision
  if(bp && bp.commentary && Array.isArray(bp.commentary[ref]) && bp.commentary[ref].length)   // commentary bundled in the book pack
    comms.push({label: bp.commentaryLabel || 'Commentary', content: bp.commentary[ref], attrib: bp.commentaryAttribution || 'Commentary included with this document.'});
  const PRF = {wcf:window.WCF_PROOFS, wlc:window.WLC_PROOFS, wsc:window.WSC_PROOFS}[current];
  const proofs = PRF ? PRF[ref] : null;
  // custom books carry no GA citations / Scripture proofs — show only what applies
  if(isCustom && (dTab==='cit'||dTab==='proofs')) dTab = comms.length?'comm':(fnotes?'fn':'notes');
  const tab=(k,label)=>`<button class="dtab${dTab===k?' on':''}" data-tab="${k}">${label}</button>`;
  let body = `<div class="section-preview">${sectionHTML(ref)}</div><div class="dtabs">${isCustom?'':tab('cit','Citations'+(n?` (${n})`:''))}${proofs?tab('proofs','Proofs'):''}${comms.length?tab('comm','Commentary'+(comms.length>1?` (${comms.length})`:'')):''}${fnotes&&fnotes.length?tab('fn','Footnotes'+(fnotes.length>1?` (${fnotes.length})`:'')):''}${tab('notes','Notes')}${hasHist?tab('hist','History'):''}</div>`;
  if(dTab==='cit'){
    const gaBrowse = `<a class="ga-browse" href="${(window.GA_BASE||'#')}app/" target="_blank" rel="noopener">Search the full GA Minutes corpus ↗</a>`;
    const rows = citRows(current, ref);          // null until the split file loads
    if(n===0){
      const emptyMessage = current==='bco'
        ? 'No high-confidence matches meet the current display cutoff. Lower-confidence links are hidden.'
        : 'No linked General Assembly records are in the authority index for this provision. The text stands on its own — when a case, overture, inquiry, committee advice, or record-review exception references it, it will surface here.';
      body += `<p class="empty-note">${emptyMessage}</p>` + gaBrowse;
    } else if(rows === null){
      body += `<p class="empty-note">Loading ${n} GA citation${n>1?'s':''}…</p>`;
      loadCitFile(current, ref).then(()=>{ if(drawerRef===ref && dTab==='cit') renderDrawer(); });
    } else {
      const counts={case:0, ov:0, inq:0, ccb:0, rpr:0, pp:0};
      rows.forEach(r=>{ counts[r.t] = (counts[r.t]||0) + 1; });
      const parts = [counts.case&&`${counts.case} case${counts.case>1?'s':''}`, counts.ov&&`${counts.ov} overture${counts.ov>1?'s':''}`,
        counts.inq&&`${counts.inq} inquir${counts.inq>1?'ies':'y'}`, counts.ccb&&`${counts.ccb} CCB advice item${counts.ccb>1?'s':''}`, counts.rpr&&`${counts.rpr} RPR`, counts.pp&&`${counts.pp} study`].filter(Boolean);
      const recordLabel = current==='bco'
        ? 'high-confidence GA match'+(n===1?'':'es')
        : 'linked GA record'+(n===1?'':'s');
      body += `<p class="dsum"><b>${n}</b> ${recordLabel} — ${parts.join(' · ')}</p>`;
      if(n>=12) body += histogram(rows);
      const chip=(k,l,c)=>`<button class="fchip${dFilter===k?' on':''}" data-filter="${k}">${l}${c!=null?` ${c}`:''}</button>`;
      body += `<div class="fchips">${chip('all','All',n)}`
        + (counts.case?chip('case','Cases',counts.case):'') + (counts.ov?chip('ov','Overtures',counts.ov):'')
        + (counts.inq?chip('inq','Inquiries',counts.inq):'') + (counts.ccb?chip('ccb','CCB advice',counts.ccb):'') + (counts.rpr?chip('rpr','RPR',counts.rpr):'') + (counts.pp?chip('pp','Studies',counts.pp):'')
        + `<button class="sortbtn" data-sort>${dSort==='desc'?'Newest first':'Oldest first'} ⇅</button></div>`;
      const types = dFilter==='all' ? ['case','ov','inq','ccb','rpr','pp'] : [dFilter];
      types.forEach(t=>{
        if(!counts[t]) return;
        const [cls,label]=TYPE_META[t];
        const trows=rows.filter(r=>r.t===t).sort((a,b)=>dSort==='desc'?(b.yr||0)-(a.yr||0):(a.yr||0)-(b.yr||0));
        body += `<div class="cgrp"><p class="cgrp-h"><span class="tag ${cls}">${label}</span><span class="cgrp-n">${counts[t]}</span></p>`
          + trows.map(r=>`<a class="cite" href="${esc(r.url)}" target="_blank" rel="noopener"><span class="yr">${r.yr||''}</span><span class="ctxt">${current==='bco'?spChip(ref,r.ttl):''}${esc(r.ttl)}${r.disp?`<span class="out">· ${esc(r.disp)}</span>`:''}</span><span class="arr">↗</span></a>`).join('') + `</div>`;
      });
      body += gaBrowse;
    }
  } else if(dTab==='proofs'){
    const RM = window.PROOF_REFMAP||{};
    const groups = (proofs.groups||[]).map(([letter,rs])=>
      `<div class="pgroup"><span class="plabel">${esc(letter)}</span><span class="prefs">${RM[rs]||esc(rs)}</span></div>`).join('');
    const tappable = groups.indexOf('class="vref"')>=0;
    body += `<div class="proofs-view">`
      + (tappable ? `<button class="vall" aria-pressed="false">Show all verse text</button>` : ``)
      + `<p class="pans">${proofs.ans||''}</p>`
      + (groups ? `<div class="pgroups">${groups}</div>` : ``)
      + `<div class="vlist"></div>`
      + `<p class="cattrib">PCA Constitution — official Scripture proofs (pcaac.org)`
      + (tappable ? ` · verse text: Berean Standard Bible (public domain)` : ``) + `</p></div>`;
  } else if(dTab==='comm'){
    const selectedPack=comms.findIndex(c=>c.label===packLabel);
    if(selectedPack>=0) dCommSel=selectedPack;
    const sel = Math.min(Math.max(dCommSel,0), comms.length-1);
    if(comms.length>1)
      body += `<div class="csubtabs">${comms.map((c,i)=>`<button class="csub${i===sel?' on':''}" data-csub="${i}">${esc(c.label.split(' — ')[0])}</button>`).join('')}</div>`;
    const c = comms[sel];
    const sectionMarkup=renderCommentarySections(c.sections||[],qNumber);
    body += `<div class="commentary">${commentaryContentHtml(c.content)}${sectionMarkup}<p class="cattrib">${esc(c.attrib || (c.label + ' — imported pack, personal use.'))}</p></div>`;
  } else if(dTab==='fn'){
    body += `<div class="commentary">${fnotes.map((p,i)=>`<p class="fn-item${dFnSel===i+1?' on':''}" id="dfn-${i+1}"><sup class="fnref">${i+1}</sup> ${p}</p>`).join('')}<p class="cattrib">Footnotes from the source document.</p></div>`;
  } else if(dTab==='notes'){
    body += notesBlock(ref);
  } else if(dTab==='hist'){
    body += `<div class="histtab">${d.amend.map(a=>`<div class="hrow"><b>${a.ga}</b> — ${a.n}</div>`).join('')}<p class="hnote">Compiled from the Digest (Part I) and verified against the minutes.</p></div>`;
  }
  document.getElementById('dBody').innerHTML = body;
  if(dTab==='fn' && dFnSel){            // scroll the drawer body to the clicked note (next frame: the panel may still be animating open)
    const tgt='dfn-'+dFnSel;
    requestAnimationFrame(()=>{ const el=document.getElementById(tgt), bd=document.getElementById('dBody');
      if(el && bd) bd.scrollTop += el.getBoundingClientRect().top - bd.getBoundingClientRect().top - 16; });
  }
}
function openDrawer(ref){
  openPanel('drawer',{ref});
}
function showDrawer(saved){
  const ref=saved.ref;
  drawerRef=ref; dFilter=saved.filter||'all'; dSort=saved.sort||'desc'; dCommSel=saved.commentary||0; dFnSel=saved.footnote||null;
  // open on Proofs for Westminster provisions (their primary apparatus), else Citations
  const PRF = {wcf:window.WCF_PROOFS, wlc:window.WLC_PROOFS, wsc:window.WSC_PROOFS}[current];
  dTab = saved.tab || ((PRF && PRF[ref] && total(dossierFor(ref))===0) ? 'proofs' : 'cit');
  renderDrawer(saved.packLabel);
  if(saved.verses?.length){
    const proofs=byId('dBody').querySelector('.proofs-view');
    if(proofs){
      const refs=proofs.querySelectorAll('.vref');
      saved.verses.forEach(i=>refs[i]?.classList.add('open'));
      rebuildVerses(proofs);
    }
  }
  const note=byId('dBody').querySelector('.note-input');
  if(note && noteDrafts.has(visit)) note.value=noteDrafts.get(visit);
  const dr=document.getElementById('drawer');
  dr.classList.add('show'); dr.setAttribute('aria-hidden','false');
  document.getElementById('overlay').classList.add('show');
  const body=byId('dBody');
  if(saved.openSections) body.querySelectorAll('details').forEach((el,i)=>{ el.open=!!saved.openSections[i]; });
  body.scrollTop=saved.top||0;
  const target=saved.commentarySectionId ? byId('commentary-'+saved.commentarySectionId) : saved.noteIndex!==undefined ? byId('dnote-'+saved.noteIndex) : null;
  if(target){
    for(let el=target; el && el!==body; el=el.parentElement){
      if(el.tagName==='DETAILS') el.open=true;
    }
    body.scrollTop+=target.getBoundingClientRect().top-body.getBoundingClientRect().top-16;
  }
  byId('closeDrawer').focus({preventScroll:true});
}
function hideDrawer(){
  const dr=document.getElementById('drawer');
  if(!dr.classList.contains('show')) return;
  if(dr.contains(document.activeElement)) document.activeElement.blur();
  dr.classList.remove('show'); dr.setAttribute('aria-hidden','true');
  document.getElementById('overlay').classList.remove('show');
  drawerRef=null;
}

/* ───────────── full-library search ───────────── */
/* Built lazily from the same provision data as the reader; installed books join this index. */
let SEARCH=null;
function _plain(html){ const d=document.createElement('div'); d.innerHTML=html||''; return (d.textContent||'').replace(/\s+/g,' ').trim(); }
function provisionLabel(book, ref){
  return book==='naparc' ? String(ref).replace(/^(?:Comity|Transfer)\.(?=\d+$)/, '') : ref;
}
function _searchRecord(book,ref,open,title,text,noDrawer=false,metadata={}){
  const label=(COMPONENTS[book]&&COMPONENTS[book].abbr)||book.toUpperCase();
  const bare=String(ref).replace(/^Q\.?\s*/i,'');
  const aliases=[`${label} ${ref}`,ref];
  if(book==='wcf') aliases.push(`Confession ${ref}`);
  if(book==='wlc') aliases.push(`Larger Catechism Q ${bare}`,`Larger Q ${bare}`);
  if(book==='wsc') aliases.push(`Shorter Catechism Q ${bare}`,`Shorter Q ${bare}`);
  if(book==='bco') aliases.push(`Book of Church Order ${ref}`);
  return {book,ref,reference:`${label} ${provisionLabel(book,ref)}`,aliases,open,title:title||'',text:text||'',sub:title||'',txt:text||'',noDrawer,...metadata};
}
function buildSearch(){
  const out=[];
  const bcoIndexTopics=window.BCO_INDEX_TOPICS||{};
  if(window.WCF) for(const ch in window.WCF){ const c=window.WCF[ch]; (c.sections||[]).forEach(s=>out.push(_searchRecord('wcf',s.ref,{ch},c.title||`Chapter ${ch}`,_plain(s.body)))); }
  [['wsc',window.WSC],['wlc',window.WLC]].forEach(([bk,arr])=>{ if(Array.isArray(arr)) arr.forEach((qa,i)=>{ const ref='Q.'+(i+1), question=_plain(qa.q); out.push(_searchRecord(bk,ref,{qStart:String(i+1),anchor:ref},question,_plain(qa.a))); }); });
  if(BCO_DATA && window.BCO_ORDER) window.BCO_ORDER.forEach(id=>{ const e=BCO_DATA[id]; (e.sections||[]).forEach(s=>{ let t=_plain(s.body); if(!t&&s.blocks) t=s.blocks.map(b=>_plain(b[b.length-1])).join(' '); const indexRef=s.ref.startsWith('PP-')?`Preface II-${s.ref.slice(3)}`:s.ref; out.push(_searchRecord('bco',s.ref,{ch:id},e.title||'',t,false,{topics:bcoIndexTopics[indexRef]||bcoIndexTopics[s.ref]||[]})); }); if(e.paras&&e.paras.length){ const ref=id.startsWith('app')?`Appendix ${id.slice(3)}`:(e.title||id); const frontRef=id==='pref-1'?'Preface I':id==='pref-2'?'Preface II':id==='pref-3'?'Preface III':ref; const topics=Object.entries(bcoIndexTopics).filter(([key])=>key===frontRef||key.startsWith(`${frontRef}-`)).flatMap(([,labels])=>labels); out.push(_searchRecord('bco',ref,{ch:id},e.title||'Book of Church Order',e.paras.map(_plain).join(' '),true,{topics:[...new Set([...(bcoIndexTopics[ref]||[]),...topics])]})); } });
  const addPackContent=(book,ref,title,content,packKind,packLabel,extra={})=>{
    const text=PcaConstitutionSearch.contentText(content).replace(/\s+/g,' ').trim();
    const target=out.find(record=>record.book===book&&record.ref===ref&&!record.packKind);
    if(text) out.push(_searchRecord(book,ref,extra.open||target?.open||{},title,text,false,{packKind,packLabel,...extra}));
  };
  window.BOOK_PACKS.forEach(bp=>{
    const k=bp.component.key;
    (bp.order||[]).forEach(id=>{
      const ch=bp.chapters[id]||{};
      (ch.sections||[]).forEach(s=>{
        const text=s.body||((s.blocks||[]).map(b=>b[0]==='i'?`${b[2]} ${b[3]}`:b[2]).join(' '));
        const prose = !!s.prose && officialSupplements.has(k);
        out.push(_searchRecord(k,s.ref||id,prose?{ch:id,anchor:s.ref}:{ch:id},ch.title||'',_plain(text),prose));
      });
    });
    Object.entries(bp.commentary||{}).forEach(([ref,content])=>addPackContent(k,ref,'Bundled commentary',content,'commentary',bp.commentaryLabel||'Commentary'));
    Object.entries(bp.footnotes||{}).forEach(([ref,content])=>addPackContent(k,ref,'Footnotes',content,'footnotes','Footnotes'));
  });
  window.BCO_COMMENTARIES.forEach(pack=>{
    const book=pack.corpus||'bco', label=pack.label||'Commentary';
    Object.entries(pack.entries||{}).forEach(([ref,content])=>addPackContent(book,ref,'Commentary',content,'commentary',label));
    (pack.sections||[]).forEach(section=>{
      const questions=Array.isArray(section.questions)?section.questions:[];
      questions.forEach(number=>{
        const ref=`Q.${number}`;
        addPackContent(book,ref,section.title||'Commentary section',section,'commentary',label,{
          open:{qStart:String(number),anchor:ref},commentarySectionId:section.id||''
        });
      });
    });
  });
  const targetsByRef=new Map();
  out.filter(record=>!record.packKind&&!record.noDrawer).forEach(record=>{
    const key=`${record.book}\u0000${record.ref}`;
    if(!targetsByRef.has(record.ref)) targetsByRef.set(record.ref,new Map());
    targetsByRef.get(record.ref).set(key,record);
  });
  Object.entries(NOTES).forEach(([ref,notes])=>{
    let targets=[...(targetsByRef.get(ref)?.values()||[])];
    if(!targets.length){
      const book=/^Q\.\d+$/i.test(ref)?'wsc':/^\d+-\d+/.test(ref)?'bco':'wcf';
      targets=[_searchRecord(book,ref,{},'Constitutional provision','')];
    }
    targets.forEach(target=>notes.forEach((note,noteIndex)=>addPackContent(target.book,ref,'Personal note',note.text||'','notes','My notes',{
      open:target.open,noteIndex
    })));
  });
  return out;
}
const BOOK_LABEL={wcf:'WCF',wlc:'WLC',wsc:'WSC',bco:'BCO'};
let palSel=0, palResults=[], palBooks=new Set(), renderedHits=0;
let lastSearchIndex=null, lastSearchKey='';
function _highlight(value,query){
  let html=esc(value||'');
  const terms=PcaConstitutionSearch.parseQuery(query).terms.concat(PcaConstitutionSearch.parseQuery(query).phrases).sort((a,b)=>b.length-a.length);
  for(const term of terms){ if(term.length<2) continue; const safe=term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); html=html.replace(new RegExp(`(${safe})`,'ig'),'<mark>$1</mark>'); }
  return html;
}
function renderPalTools(total){
  const books=[...new Set(SEARCH.map(h=>h.book))];
  document.getElementById('palTools').innerHTML=books.map(book=>{
    const label=BOOK_LABEL[book]||(COMPONENTS[book]&&COMPONENTS[book].abbr)||book.toUpperCase();
    return `<button class="pal-filter" type="button" data-search-book="${esc(book)}" aria-pressed="${palBooks.has(book)}">${esc(label)}</button>`;
  }).join('')+`<span class="pal-meta" role="status">${total?`${total} result${total===1?'':'s'}`:'Full-text search'}</span>`;
}
function palRender(q){
  if(!SEARCH) SEARCH=buildSearch();
  const query=q.trim();
  const key=JSON.stringify([query,...palBooks]);
  if(lastSearchIndex===SEARCH && lastSearchKey===key) return;
  lastSearchIndex=SEARCH; lastSearchKey=key;
  const list=byId('palHits');
  list.replaceChildren(); list.scrollTop=0; renderedHits=0; palSel=0;
  if(!query){ palResults=[]; renderPalTools(0); list.innerHTML=`<div class="pal-empty"><b>Search every provision</b><br>Enter a reference, wording you remember, or a topic. Minor spelling mistakes are okay; put an exact phrase in quotation marks.</div>`; return; }
  const result=PcaConstitutionSearch.search(SEARCH,query,{books:palBooks});
  palResults=result.results.map(row=>({...row.record,_match:row}));
  renderPalTools(result.total);
  appendHits(50);
  if(!palResults.length) list.innerHTML='<div class="pal-empty"><b>No matching provision.</b><br>Check the reference or try fewer words. Search is spelling-tolerant for words of four or more letters.</div>';
}
function appendHits(end){
  const query=byId('palInput').value.trim();
  const hits=palResults.slice(renderedHits,end).map((h,offset)=>{
    const i=renderedHits+offset;
    const row=h._match, source=row.bestField==='title'?(h.title||h.text):row.bestField==='topics'?(h.topics||[]).join(' · '):h.text;
    const snippet=PcaConstitutionSearch.excerpt(source,row.bestToken,190);
    return `<div class="hit ${i===0?'sel':''}" data-i="${i}" role="option" aria-selected="${i===0}"><span class="ref">${esc(h.reference)}${h.packLabel?`<small class="source">${esc(h.packLabel)}</small>`:''}</span><span class="title">${_highlight(h.title||'Constitutional provision',query)}</span><span class="txt">${_highlight(snippet,query)}</span></div>`;
  }).join('');
  byId('palHits').insertAdjacentHTML('beforeend',hits);
  renderedHits=Math.min(end,palResults.length);
}
function selectHit(index,reveal){
  palSel=Math.max(0,Math.min(index,palResults.length-1));
  if(reveal && palSel>=renderedHits) appendHits(palSel+50);
  document.querySelectorAll('#palHits .hit').forEach((el,i)=>{
    const selected=i===palSel;
    el.classList.toggle('sel',selected); el.setAttribute('aria-selected',selected);
    if(selected && reveal) el.scrollIntoView({block:'nearest'});
  });
}
function restoreSearch(saved={}){
  const input=byId('palInput');
  input.value=saved.query||'';
  palBooks=new Set(saved.books);
  palRender(input.value);
  if(saved.index>=renderedHits) appendHits(saved.index+50);
  byId('palHits').scrollTop=saved.top||0;
  selectHit(saved.index||0,visit.panel==='search');
}
function passageRoute(book,target){
  const anchor=target.anchor;
  if(anchor && (COMPONENTS[book].mode==='scroll' || pagedRoute(book,anchor).ch===String(target.ch))) return book+'/'+anchor;
  return book+'/'+target.ch;
}
function palGo(i){
  const hit=palResults[i]; if(!hit) return;
  const stepping=!!visit.match;
  const search=stepping?{...visit.match.search,index:i}:{...searchPosition(),index:i};
  palSel=i;
  const target=hit.noDrawer?hit.open:{...hit.open,anchor:hit.ref};
  const match={origin:stepping?visit.match.origin:visit.key,search};
  const options=hit.packKind==='notes'?{tab:'notes',noteIndex:hit.noteIndex}
    :hit.packKind==='commentary'?{tab:'comm',packLabel:hit.packLabel}
      :hit.packKind==='footnotes'?{tab:'fn'}:{};
  if(hit.commentarySectionId) options.commentarySectionId=hit.commentarySectionId;
  writeVisit({route:passageRoute(hit.book,target),target,match,panel:hit.noDrawer?null:'drawer',drawer:{ref:hit.ref,...options}},stepping);
}
function renderMatchNav(){
  byId('pageMatches').replaceChildren();
  byId('drawerMatches').replaceChildren();
  if(!visit.match) return;
  const host=byId(visit.panel==='drawer'?'drawerMatches':'pageMatches');
  host.innerHTML='<button data-results>‹ Back to results</button>'
    +'<button data-step="-1" aria-label="Previous match" '+(palSel===0?'disabled':'')+'>‹</button>'
    +'<span aria-live="polite">Match '+(palSel+1)+' of '+palResults.length+'</span>'
    +'<button data-step="1" aria-label="Next match" '+(palSel+1>=palResults.length?'disabled':'')+'>›</button>';
}
function openPal(){ openPanel('search'); }

/* tappable proof refs → reveal BSB verse text below the proof (per-ref + expand-all) */
function rebuildVerses(view){
  if(!view) return;
  const list=view.querySelector('.vlist'); if(!list) return;
  const V=window.VERSES||{}; let out='';
  view.querySelectorAll('.vref.open').forEach(a=>{
    const keys=(a.dataset.v||'').split('|').filter(Boolean);
    const multi=keys.length>1;
    const lines=keys.map(k=>{ const t=V[k]; if(!t) return '';
      const vn=multi?`<span class="vn">${esc(k.split(' ').pop())}</span>`:'';   // verse "ch:v" tag, only when a ref spans >1 verse
      return `<div class="vline">${vn}${esc(t)}</div>`; }).filter(Boolean).join('');
    if(lines) out+=`<div class="vblock"><div class="vbref">${a.textContent}</div>${lines}</div>`;
  });
  list.innerHTML=out;
  const btn=view.querySelector('.vall');
  if(btn){ const all=view.querySelectorAll('.vref').length, open=view.querySelectorAll('.vref.open').length;
    const allOpen=all>0&&open===all; btn.setAttribute('aria-pressed',allOpen); btn.textContent=allOpen?'Hide all verse text':'Show all verse text'; }
}
/* tapping a reference is exclusive: reveal just that one, removing any other open ref (toggle off if already open) */
function toggleVref(vr){
  const view=vr.closest('.proofs-view'); if(!view) return;
  const was=vr.classList.contains('open');
  view.querySelectorAll('.vref.open').forEach(x=>x.classList.remove('open'));
  if(!was) vr.classList.add('open');
  rebuildVerses(view);
}

/* ───────────── events ───────────── */
function closeMenu(){ const m=document.getElementById('mobileMenu'); if(m){ m.classList.remove('open'); const b=document.getElementById('hamburger'); b.setAttribute('aria-expanded','false'); b.setAttribute('aria-label','Open menu'); } }
byId('readerBack').addEventListener('click',readerBack);
document.getElementById('brand').addEventListener('click', ()=>{ closeMenu(); navigatePage(''); });
document.getElementById('books').addEventListener('click', e=>{ const b=e.target.closest('button'); if(b) navigatePage(b.dataset.book); });
byId('hamburger').addEventListener('click', ()=>{ if(visit.panel==='menu') readerBack(); else openPanel('menu'); });
document.body.addEventListener('click', e=>{
  if(e.target.closest('a[href="#"]')) e.preventDefault();   // placeholder citation links: don't navigate to '#'
  if(visit.panel==='menu' && !e.target.closest('#mobileMenu,#hamburger,#readerBack,[data-book],[data-home],[data-about],[data-anchor],[data-ref],.bn,.home-jump')){
    dismissPanel(); return;
  }
  if(e.target.closest('[data-results]')){ readerBack(); return; }
  const step=e.target.closest('[data-step]');
  if(step){
    palGo(palSel+Number(step.dataset.step));
    const nav=byId(visit.panel==='drawer'?'drawerMatches':'pageMatches');
    (nav.querySelector('[data-step="'+step.dataset.step+'"]:enabled')||nav.querySelector('[data-results]')).focus({preventScroll:true});
    return;
  }
  const scripture=e.target.closest('.scripture-reference');
  if(scripture){ showScripturePreview(scripture); return; }
  const crossReference=e.target.closest('.cross-reference,#referencePreviewOpen');
  if(crossReference && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey){
    e.preventDefault();
    if(crossReference.id==='referencePreviewOpen'){
      byId('referencePreview').close();
      const route=decodeURIComponent(crossReference.hash.slice(1));
      navigatePage(route);
      const destination=byId('p-'+route.split('/')[1])?.querySelector('.n') || byId('doc').querySelector('h1');
      if(destination?.tagName==='H1') destination.tabIndex=-1;
      destination?.focus({preventScroll:true});
    }else showReferencePreview(crossReference);
    return;
  }
  const indexLink=e.target.closest('.bco-index-link');
  if(indexLink && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey){
    e.preventDefault();
    navigatePage(indexLink.hash.slice(1)); return;
  }
  const ja=e.target.closest('[data-anchor]');
  if(ja){
    const target={...cur.o,anchor:ja.dataset.anchor};
    navigatePage(passageRoute(current,target),target); return;
  }
  const ns = e.target.closest('.note-save'); if(ns){ const ta=document.querySelector('#drawer .note-input'); const v=ta&&ta.value.trim(); if(v){ (NOTES[drawerRef]=NOTES[drawerRef]||[]).push({who:"You", when:noteDate(), text:v}); saveNotes(); SEARCH=null; } dTab='notes'; renderDrawer(); return; }
  const nd = e.target.closest('.note-del'); if(nd){ const i=+nd.dataset.i; if(NOTES[drawerRef]){ NOTES[drawerRef].splice(i,1); if(!NOTES[drawerRef].length) delete NOTES[drawerRef]; } saveNotes(); SEARCH=null; dTab='notes'; renderDrawer(); return; }
  const cb = e.target.closest('.csub'); if(cb){ dCommSel=+cb.dataset.csub; renderDrawer(); return; }
  const dt = e.target.closest('.dtab'); if(dt){ dTab=dt.dataset.tab; renderDrawer(); return; }
  const fc = e.target.closest('.fchip'); if(fc){ dFilter=fc.dataset.filter; renderDrawer(); return; }
  if(e.target.closest('.sortbtn')){ dSort = dSort==='desc'?'asc':'desc'; renderDrawer(); return; }
  const cc = e.target.closest('.copy-cite'); if(cc){ const orig=cc.textContent, txt = cc.hasAttribute('data-copytext') ? (cc.dataset.cite + '. ' + sectionText(drawerRef)) : cc.dataset.cite; try{ navigator.clipboard.writeText(txt); }catch(_){ } cc.textContent='Copied ✓'; setTimeout(()=>{ if(document.body.contains(cc)) cc.textContent=orig; }, 1600); return; }
  const vr = e.target.closest('.vref'); if(vr){ toggleVref(vr); return; }
  const va = e.target.closest('.vall'); if(va){ const view=va.closest('.proofs-view'); const open=va.getAttribute('aria-pressed')!=='true'; view.querySelectorAll('.vref').forEach(a=>a.classList.toggle('open',open)); rebuildVerses(view); return; }
  if(e.target.closest('.home-jump')){ openPal(); return; }
  const mm = e.target.closest('.mm-item'); if(mm){ if(mm.hasAttribute('data-home')) navigatePage(''); else if(mm.hasAttribute('data-install')){ dismissPanel(); promptInstall(); } else if(mm.hasAttribute('data-import')) openPanel('packs'); else if(mm.hasAttribute('data-about')) navigatePage('about'); else if(mm.hasAttribute('data-share')){ dismissPanel(); shareApp(); } else navigatePage(mm.dataset.book); return; }
  const bn = e.target.closest('.bn'); if(bn){ const a=bn.dataset.bn; if(a==='library') navigatePage(''); else if(a==='search') openPal(); else navigatePage(current==='bco-subject-index'?'bco':current==='incorporation'?'':current); return; }
  const about = e.target.closest('[data-about]'); if(about){ navigatePage('about'); return; }
  const home = e.target.closest('[data-home]'); if(home){ navigatePage(''); return; }
  const bookLink = e.target.closest('.rail-back,.read-back,.entry,.hentry'); if(bookLink){ navigatePage(bookLink.dataset.book); return; }
  const toc = e.target.closest('.toc a'); if(toc){ openFromEl(toc); return; }
  const pg = e.target.closest('.pgnav'); if(pg){ pg.hasAttribute('data-contents') ? navigatePage(pg.dataset.book) : openFromEl(pg); return; }
  const den = e.target.closest('.density button'); if(den){ document.getElementById('doc').className='doc cat-'+den.dataset.density; document.querySelectorAll('.density button').forEach(b=>b.setAttribute('aria-pressed', b===den)); return; }
  const sig = e.target.closest('.sig, .sig-inline'); if(sig){ openDrawer(sig.dataset.ref); return; }
  const fn = e.target.closest('.fnref'); if(fn){ const pv=fn.closest('.prov[id]'); if(pv){ openDrawer(pv.id.slice(2)); dTab='fn'; dFnSel=parseInt(fn.textContent,10)||null; renderDrawer(); } return; }
  const n = e.target.closest('.n'); if(n){ openDrawer(n.dataset.ref); return; }
  const pf = e.target.closest('.pf-toggle'); if(pf){ pf.nextElementSibling.classList.toggle('open'); return; }
  const pm = e.target.closest('.pf-more'); if(pm){ const v=pm.nextElementSibling; v.classList.toggle('open'); pm.textContent = v.classList.contains('open')?'Hide full text ▴':'Show full text ▾'; return; }
  const ql = e.target.closest('.cat-list .prov.q'); if(ql){ ql.classList.toggle('expanded'); return; }
});
byId('closeDrawer').addEventListener('click', dismissPanel);
byId('overlay').addEventListener('click', dismissPanel);
document.getElementById('openPal').addEventListener('click', openPal);
/* Switch the BCO in place, keeping the current route and rebuilding translated navigation/search. */
function setBcoLanguage(preference){
  BCO_EDITION=chooseBcoEdition(preference);
  BCO_DATA=BCO_EDITION.map;
  COMPONENTS.bco=bcoComponent();
  if(window.BCO_ORDER) SPINE.bco=window.BCO_ORDER.map(id=>({part:BCO_DATA[id].part, ch:id, title:BCO_DATA[id].title, vacated:BCO_DATA[id].vacated}));
  SEARCH=null;
  try{
    if(preference==='auto') localStorage.removeItem('pcacon.bcoLanguage');
    else localStorage.setItem('pcacon.bcoLanguage',preference);
  }catch(_){}
  applyRoute();
}
const languageSelect=document.getElementById('bcoLanguage');
languageSelect.add(new Option('Browser default','auto'));
languageSelect.add(new Option('English','en'));
const languageNames={es:'Español',ko:'한국어'};
const offeredLanguages=new Set(['en']);
bcoTranslations().forEach(pack=>{
  const lang=String(pack.component.language).toLowerCase().split(/[-_]/)[0];
  if(!offeredLanguages.has(lang)){
    languageSelect.add(new Option(languageNames[lang]||lang,lang));
    offeredLanguages.add(lang);
  }
});
const savedLanguage=readBcoLanguage();
languageSelect.value=offeredLanguages.has(savedLanguage)?savedLanguage:'auto';
languageSelect.addEventListener('change',()=>setBcoLanguage(languageSelect.value));
byId('palClose').addEventListener('click', dismissPanel);
byId('palWrap').addEventListener('click', e=>{ if(e.target.id==='palWrap') dismissPanel(); });
document.getElementById('palTools').addEventListener('click', e=>{
  const b=e.target.closest('[data-search-book]'); if(!b) return;
  const book=b.dataset.searchBook; palBooks.has(book)?palBooks.delete(book):palBooks.add(book);
  palRender(document.getElementById('palInput').value);
  rememberVisit(true);
});

/* ── packs & notes panel ── */
function renderPacks(){
  const nc = Object.values(NOTES).reduce((a,x)=>a+x.length,0);
  const haveComm = new Set(window.BCO_COMMENTARIES.map(c=>c.label));
  const haveBook = new Set(window.BOOK_PACKS.map(b=>b.component.key));
  const available = (window.BUNDLED_PACKS||[]).filter(p=>p.component?.translationOf!=='bco' && (p.kind==='book' ? !haveBook.has(p.component.key) : !haveComm.has(p.label)));
  const bookSecs = p => Object.values(p.chapters||{}).reduce((a,c)=>a+((c.sections||[]).length),0);
  document.getElementById('packsBody').innerHTML =
      `<div class="pack-row"><div><b>My notes</b><span class="pack-sub">${nc} note${nc!==1?'s':''} · stored on this device</span></div><button class="pack-btn" data-act="export-notes"${nc?'':' disabled'}>Export…</button></div>`
    + window.BCO_COMMENTARIES.map((c,i)=>`<div class="pack-row"><div><b>${c.label}</b><span class="pack-sub">Commentary · ${Object.keys(c.entries||{}).length+(c.sections||[]).length} sections</span></div><button class="pack-btn" data-act="rm-comm" data-i="${i}">Remove</button></div>`).join('')
    + window.BOOK_PACKS.filter(b=>!officialSupplements.has(b.component.key)).map(b=>`<div class="pack-row"><div><b>${b.component.name}</b><span class="pack-sub">Book · ${bookSecs(b)} sections</span></div><button class="pack-btn" data-act="rm-book" data-key="${b.component.key}">Remove</button></div>`).join('')
    + available.map(p=>`<div class="pack-row"><div><b>${p.kind==='book'?p.component.name:p.label}</b><span class="pack-sub">${p.notice||((p.kind==='book'?'Book · '+bookSecs(p):'Commentary · '+Object.keys(p.entries).length)+' sections · public domain, included')}</span></div><button class="pack-btn" data-act="add-bundled" data-label="${p.label}">Add</button></div>`).join('')
    + `<button class="pack-btn import" data-act="import">Import a file…</button>`
    + `<p class="packs-note">Notes and imported books are kept in this browser's local storage and survive reloads. You can import a content pack or a historical BCO edition snapshot JSON. Public-domain packs (Ramsay commentary; a sample book) are included — just tap <b>Add</b>. Copyrighted commentary (e.g. Smith) isn't bundled; import it as your own JSON file. Imported books appear alongside the four standards. Everything exports/imports as portable JSON.</p>`;
}
byId('packClose').addEventListener('click', dismissPanel);
byId('packWrap').addEventListener('click', e=>{ if(e.target.id==='packWrap') dismissPanel(); });
document.getElementById('packsBody').addEventListener('click', e=>{
  const b=e.target.closest('[data-act]'); if(!b) return;
  if(b.dataset.act==='export-notes') exportNotes();
  else if(b.dataset.act==='import') document.getElementById('importFile').click();
  else if(b.dataset.act==='rm-comm'){ window.BCO_COMMENTARIES.splice(+b.dataset.i,1); saveCommentaries(); SEARCH=null; renderPacks(); if(document.getElementById('drawer').classList.contains('show')) renderDrawer(); }
  else if(b.dataset.act==='rm-book'){ const k=b.dataset.key; window.BOOK_PACKS=window.BOOK_PACKS.filter(x=>x.component.key!==k); delete COMPONENTS[k]; delete SPINE[k]; saveBooks(); SEARCH=null; refreshNav(); renderPacks(); if(current===k) writeVisit({route:'',panel:'packs',y:0},true); else if(view==='home') showHome(); }
  else if(b.dataset.act==='add-bundled'){ const p=(window.BUNDLED_PACKS||[]).find(x=>x.label===b.dataset.label); if(p){ importPack(p); SEARCH=null; if(p.kind==='book') refreshNav(); renderPacks(); if(view==='home') showHome(); else if(document.getElementById('drawer').classList.contains('show')) renderDrawer(); } }
});
document.getElementById('importFile').addEventListener('change', e=>{
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{ try{ const res=importPack(JSON.parse(r.result)); SEARCH=null; if(res.kind==='book') refreshNav(); renderPacks(); if(view==='home') showHome(); else if(document.getElementById('drawer').classList.contains('show')) renderDrawer(); alert(`Imported ${res.kind} pack — ${res.n} ${res.kind==='book'?'sections':'entries'}.`); }catch(err){ alert('Import failed: '+err.message); } };
  r.readAsText(f); e.target.value='';
});
document.getElementById('palInput').addEventListener('input', e=>{ palRender(e.target.value); rememberVisit(true); });
document.getElementById('palHits').addEventListener('click', e=>{ const h=e.target.closest('.hit'); if(h&&h.dataset.i!=null) palGo(+h.dataset.i); });
byId('palHits').addEventListener('scroll', e=>{
  const list=e.currentTarget;
  if(renderedHits<palResults.length && list.scrollTop+list.clientHeight>=list.scrollHeight-100) appendHits(renderedHits+50);
},{passive:true});
document.getElementById('palInput').addEventListener('keydown', e=>{
  if(e.key==='ArrowDown'){ e.preventDefault(); palSel=Math.min(palSel+1,palResults.length-1); }
  else if(e.key==='ArrowUp'){ e.preventDefault(); palSel=Math.max(palSel-1,0); }
  else if(e.key==='Enter'){ e.preventDefault(); palGo(palSel); return; }
  else return;
  selectHit(palSel,true);
  rememberVisit(true);
});
document.addEventListener('keydown', e=>{
  if(byId('referencePreview').open) return;
  if((e.metaKey||e.ctrlKey)&&e.key==='k'){ e.preventDefault(); openPal(); }
  if(e.key==='Escape'){
    dismissPanel();
  }
});

/* keyboard activation for the provision number + proof toggle (role="button") */
document.addEventListener('keydown', e=>{
  if(e.key!=='Enter' && e.key!==' ') return;
  const t=e.target; if(!t.classList) return;
  if(t.classList.contains('n')){ e.preventDefault(); openDrawer(t.dataset.ref); }
  else if(t.classList.contains('pf-toggle')){ e.preventDefault(); t.nextElementSibling.classList.toggle('open'); }
  else if(t.classList.contains('vref')){ e.preventDefault(); toggleVref(t); }
});

/* ── sequential nav: ← / → arrow keys (desktop) ── */
document.addEventListener('keydown', e=>{
  if(view!=='read') return;
  if(e.metaKey||e.ctrlKey||e.altKey) return;
  if(/^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName||''))) return;
  if(document.getElementById('palWrap').classList.contains('show')) return;
  if(e.key==='ArrowRight'){ goRelative(1); }
  else if(e.key==='ArrowLeft'){ goRelative(-1); }
});

/* ── sequential nav: horizontal swipe (touch) ── */
let tsX=0, tsY=0, tracking=false;
document.addEventListener('touchstart', e=>{
  // ignore swipes that begin on the open drawer/sheet or the palette
  if(view!=='read') { tracking=false; return; }
  if(document.getElementById('drawer').classList.contains('show')) { tracking=false; return; }
  const t=e.changedTouches[0]; tsX=t.clientX; tsY=t.clientY; tracking=true;
}, {passive:true});
document.addEventListener('touchend', e=>{
  if(!tracking) return; tracking=false;
  const t=e.changedTouches[0], dx=t.clientX-tsX, dy=t.clientY-tsY;
  // horizontal-dominant gesture past threshold → turn page (vertical scroll untouched)
  if(Math.abs(dx)>70 && Math.abs(dx) > Math.abs(dy)*1.8){ goRelative(dx<0 ? 1 : -1); }
}, {passive:true});

function refreshNav(){   // inject header + hamburger entries for pack-added books (built-ins are static HTML)
  document.querySelectorAll('[data-customnav]').forEach(el=>el.remove());
  const books=document.getElementById('books'), menu=document.getElementById('mmDocuments');
  window.BOOK_PACKS.forEach(bp=>{
    const c=bp.component;
    if(books){ const b=document.createElement('button'); b.dataset.book=c.key; b.setAttribute('data-customnav','1'); b.textContent=c.abbr||c.name; books.appendChild(b); }
    if(menu){ const m=document.createElement('button'); m.className='mm-item'; m.dataset.book=c.key; m.setAttribute('data-customnav','1'); m.textContent=c.name; menu.appendChild(m); }
  });
}
history.scrollRestoration='manual';
window.addEventListener('popstate', e=>restoreVisit(e.state));
window.addEventListener('pagehide', ()=>rememberVisit(true));
refreshNav();
restoreVisit(history.state);

/* ── PWA: capture the install prompt so the hamburger "Install app" item can fire it ── */
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt', e=>{ e.preventDefault(); deferredPrompt=e; });
window.addEventListener('appinstalled', ()=>{ deferredPrompt=null; const b=document.getElementById('mmInstall'); if(b) b.style.display='none'; });
if(matchMedia('(display-mode: standalone)').matches || navigator.standalone){ const b=document.getElementById('mmInstall'); if(b) b.style.display='none'; }
function promptInstall(){
  if(deferredPrompt){ deferredPrompt.prompt(); const c=deferredPrompt.userChoice; deferredPrompt=null; if(c&&c.finally) c.finally(()=>{}); return; }
  const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
  alert(ios
    ? 'To install on iPhone/iPad: in Safari tap the Share button, then “Add to Home Screen.”'
    : 'If no install prompt appears, open your browser menu and choose “Install app” / “Add to Home screen.” (It may already be installed.)');
}

/* ── native share (Web Share API) with clipboard fallback; delegates to the OS share sheet ── */
async function shareData(d){
  if(navigator.share){
    try{ await navigator.share(d); return 'shared'; }
    catch(e){ if(e && e.name==='AbortError') return 'cancel'; }
  }
  try{ await navigator.clipboard.writeText(d.url || d.text || ''); return 'copied'; }catch(_){ return 'fail'; }
}
function appURL(){ return location.origin + location.pathname; }
async function shareApp(){
  const url=appURL();
  const r=await shareData({title:'PCA Constitution', text:'The Constitution of the Presbyterian Church in America — the Westminster Standards and the Book of Church Order, with General Assembly citations.', url});
  if(r==='copied') alert('Link copied:\n'+url);
}

/* ── PWA: register the service worker (installable + full offline) ── */
if('serviceWorker' in navigator && !window.Capacitor?.isNativePlatform?.()){
  const previousWorker=navigator.serviceWorker.controller;
  if(previousWorker){
    navigator.serviceWorker.addEventListener('controllerchange', ()=>{
      if(navigator.serviceWorker.controller!==previousWorker) window.location.reload();
    }, {once:true});
  }
  window.addEventListener('load', ()=>{ navigator.serviceWorker.register('sw.js').catch(()=>{}); });
}

window.__pcaReaderReady = true;
